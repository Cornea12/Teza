<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%payment}}`.
 */
class m220508_155636_create_payment_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%payment}}', [
            'id' => $this->primaryKey(),
            'payment_code' => $this->string(),
            'order_id' => $this->integer(),
            'user_id' => $this->integer(),
            'amount' => $this->float(),
            'payment_at_deliver' => $this->integer(),
            'status' => $this->integer(),
            //Dacă plata se face la fața locului este necesar de a face update daca e plata e facuta online valoare este 0,
            'admin_id_update' => $this->integer(),
            'created_at' => $this->integer(),
            'updated_at' => $this->integer(),
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%payment}}');
    }
}
