<?php

use yii\db\Migration;

/**
 * Class m220511_133147_create_rbac_data
 */
class m220511_133147_create_rbac_data extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {

      $auth = Yii::$app->authManager;

      // add "create" permission
          $create = $auth->createPermission('create');
          $create->description = 'Create ';
          $auth->add($create);

      // add "update" permission
          $update = $auth->createPermission('update');
          $update->description = 'update ';
          $auth->add($update);

      // add "view" permission
          $view = $auth->createPermission('view');
          $view->description = 'view';
          $auth->add($view);

      // add "delete" permission
          $delete = $auth->createPermission('delete');
          $delete->description = 'delete';
          $auth->add($delete);

    //create role admin
       $admin = $auth->createRole('admin');
       $auth->add($admin);

    //create role moderator
       $moderator = $auth->createRole('moderator');
       $auth->add($moderator);

    //create role contentManager
      $contentManager = $auth->createRole('contentManager');
      $auth->add($contentManager);


       $auth->addChild($moderator, $create);
       $auth->addChild($moderator, $update);
       $auth->addChild($moderator, $view);


       $auth->addChild($admin, $moderator);
       $auth->addChild($admin, $delete);

    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m220511_133147_create_rbac_data cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m220511_133147_create_rbac_data cannot be reverted.\n";

        return false;
    }
    */
}
