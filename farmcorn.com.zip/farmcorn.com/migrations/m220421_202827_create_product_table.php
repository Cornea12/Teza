<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%product}}`.
 */
class m220421_202827_create_product_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%product}}', [
            'id' => $this->primaryKey(),
            'name' => $this->string(),
            'url' => $this->string(),
            'description' => $this->text(),
            'price' => $this->float(),
            'stock' => $this->integer(),
            'discount' => $this->float(),
            'image' => $this->string(),
            'category_id' => $this->integer(),
            'producer_id' => $this->integer(),
            'status' => $this->integer(),
            'created_by' => $this->integer(),
            'updated_by' => $this->integer(),
            'created_at' => $this->integer(),
            'updated_at' => $this->integer()
        ]);



        // creates index for column `category_id`
        $this->createIndex(
            'idx-product-category_id',
            'product',
            'category_id'
        );

        // add foreign key for table `product_category` NO CASCADE ON DELETE
        $this->addForeignKey(
            'fk-product-category_id',
            'product',
            'category_id',
            'product_category',
            'id',
        );

        // creates index for column `category_id`
        $this->createIndex(
            'idx-product-producer_id',
            'product',
            'producer_id'
        );

        // add foreign key for table `producer` NO CASCADE ON DELETE
        $this->addForeignKey(
            'fk-product-producer_id',
            'product',
            'producer_id',
            'producer',
            'id',
        );

        // creates index for column `created_by`
        $this->createIndex(
            'idx-product-created_by',
            'product',
            'created_by'
        );

        // add foreign key for table `user` NO CASCADE ON DELETE
        $this->addForeignKey(
            'fk-product-created_by',
            'product',
            'created_by',
            'users',
            'id',
        );

        // creates index for column `updated_by`
        $this->createIndex(
            'idx-product-updated_by',
            'product',
            'updated_by'
        );

        // add foreign key for table `users` NO CASCADE ON DELETE
        $this->addForeignKey(
            'fk-product-updated_by',
            'product',
            'updated_by',
            'users',
            'id',
        );
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%product}}');
    }
}
