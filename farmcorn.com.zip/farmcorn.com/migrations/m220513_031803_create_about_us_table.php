<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%about_us}}`.
 */
class m220513_031803_create_about_us_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%about_us}}', [
          'id' => $this->primaryKey(),
          'title' => $this->string(),
          'content' => $this->text(),
          'created_at' => $this->integer(),
          'updated_at' => $this->integer(),
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%about_us}}');
    }
}
