<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%order}}`.
 */
class m220508_152643_create_order_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%order}}', [
            'id' => $this->primaryKey(),
            'oreder_code' => $this->string(),
            'user_id' => $this->integer(),
            'quantity' => $this->integer(),
            'amount' => $this->float(),
            'firstname' => $this->string(),
            'lastname' => $this->string(),
            'email' => $this->string(),
            'phone' => $this->integer(),
            'address' => $this->string(),
            'zip_code' => $this->integer(),
            'payment_id' => $this->integer(),
            'created_at' => $this->integer(),
            'updated_at' => $this->integer(),
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%order}}');
    }
}
