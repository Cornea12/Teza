<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%cart}}`.
 */
class m220505_112428_create_cart_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%cart}}', [
            'id' => $this->primaryKey(),
            'product_id' => $this->integer(),
            'title' => $this->string(),
            'quantity' => $this->integer(),
            'price' => $this->float(),
            'image' => $this->string(),
            'path' => $this->string(),
            'user_id' => $this->integer(),
            'created_at' => $this->integer(),
            'updated_at' => $this->integer(),
        ]);



        // creates index for column `user_id`
        $this->createIndex(
            'idx-cart-user_id',
            'cart',
            'user_id'
        );

        // add foreign key for table `user`
        $this->addForeignKey(
            'fk-cart-user_id',
            'cart',
            'user_id',
            'users',
            'id',
            'CASCADE'
        );

        // creates index for column `product_id`
        $this->createIndex(
            'idx-cart-product_id',
            'cart',
            'product_id'
        );

        // add foreign key for table `product`
        $this->addForeignKey(
            'fk-cart-product_id',
            'cart',
            'product_id',
            'product',
            'id',
            'CASCADE'
        );
    }


    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%cart}}');
    }
}
