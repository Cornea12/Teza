<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%product_category}}`.
 */
class m220421_202938_create_product_category_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%product_category}}', [
            'id' => $this->primaryKey(),
            'name' => $this->string(),
            'status' => $this->integer(),
            'created_by' => $this->integer(),
            'updated_by' => $this->integer(),
            'created_at' => $this->integer(),
            'updated_at' => $this->integer()
        ]);

        // creates index for column `created_by`
        $this->createIndex(
            'idx-product_category-created_by',
            'product_category',
            'created_by'
        );

        // add foreign key for table `user` NO CASCADE ON DELETE
        $this->addForeignKey(
            'fk-product_category-created_by',
            'product_category',
            'created_by',
            'users',
            'id',
        );

        // creates index for column `updated_by`
        $this->createIndex(
            'idx-product_category-updated_by',
            'product_category',
            'updated_by'
        );

        // add foreign key for table `users` NO CASCADE ON DELETE
        $this->addForeignKey(
            'fk-product_category-updated_by',
            'product_category',
            'updated_by',
            'users',
            'id',
        );
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%product_category}}');
    }
}
