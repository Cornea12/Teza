<?php

namespace app\models\ProductCategory;

use Yii;
use app\models\User\User;
use app\models\Product\Product;

/**
 * This is the model class for table "product_category".
 *
 * @property int $id
 * @property string|null $name
 * @property int|null $status
 * @property int|null $created_by
 * @property int|null $updated_by
 * @property int|null $created_at
 * @property int|null $updated_at
 *
 * @property Users $createdBy
 * @property Product[] $products
 * @property Users $updatedBy
 */
class ProductCategory extends \yii\db\ActiveRecord
{

  CONST CATEGORY_ACTIVE = 1;
  CONST CATEGORY_INACTIVE = 0;
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'product_category';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['status', 'created_by', 'updated_by', 'created_at', 'updated_at'], 'integer'],
            [['name'], 'string', 'max' => 255],
            [['name'], 'trim'],
            [['name'], 'required'],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['created_by' => 'id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['updated_by' => 'id']],
            [['created_by', 'updated_by'], 'default', 'value' => Yii::$app->user->identity->id],
            [['created_at', 'updated_at'], 'default', 'value' => time()],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Denumire producător',
            'status' => 'Statut',
            'created_by' => 'Creat de',
            'updated_by' => 'Modificat de',
            'created_at' => 'Creat la data',
            'updated_at' => 'Actualizat la data',
        ];
    }


    public function beforeValidate()
    {
      $this->name = htmlspecialchars($this->name);
      $this->status = htmlspecialchars($this->status);

      return parent::beforeValidate();
    }

    /**
     * Gets query for [[CreatedBy]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'created_by']);
    }

    /**
     * Gets query for [[Products]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProducts()
    {
        return $this->hasMany(Product::className(), ['category_id' => 'id']);
    }

    public function getProductsByCategory()
    {
        return $this->hasMany(Product::className(), ['category_id' => 'id'])->where(['status' => 1])->orderBy('updated_at desc')->limit(6)->all();
    }

    public static function findCategory()
    {
      return ProductCategory::find()->where(['status' => 1])->all();
    }

    /**
     * Gets query for [[UpdatedBy]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'updated_by']);
    }

    public function updateData()
    {
      $this->updated_at = time();
      $this->updated_by = Yii::$app->user->identity->id;

      return $this->save();
    }
}
