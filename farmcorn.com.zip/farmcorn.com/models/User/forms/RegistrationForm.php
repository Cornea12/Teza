<?php

namespace app\models\User\Forms;

use Yii;
use yii\base\Model;
use app\models\User\User;

/**
 *
 */
class RegistrationForm extends Model
{

  public $firstname;
  public $lastname;
  public $email;
  public $password;
  public $password_repeat;



// Functia pentru validare RegisterForm
// Function for RegisterForm Validation
  public function rules()
  {
      return [
        [['firstname', 'lastname', 'email', 'password', 'password_repeat'], 'required'],

        [['firstname', 'lastname','email',  'password', 'password_repeat'], 'trim'],

        [['firstname', 'lastname'], 'string', 'min'=>2, 'max'=>20],

        [['password'], 'string', 'min'=>6, 'max' => 12],


        [['password_repeat'], 'compare', 'compareAttribute'=>'password', 'message'=>"Parolele nu coincid"],

        // [['email'], 'email'],

        [['email'], 'unique', 'targetClass'=>User::className()],
      ];
  }

  public function register()
  {
    $user = new User;
    $user->firstname = $this->firstname;
    $user->lastname = $this->lastname;
    $user->email = $this->email;
    $user->password = Yii::$app->security->generatePasswordHash($this->password);
    $user->email_token = Yii::$app->security->generateRandomString(10);
    $user->auth_key = Yii::$app->security->generateRandomString();
    $user->status = User::USER_INACTIVE;
    $user->created_at = $time = time();
    $user->updated_at = $time;
    $user->sendConfirmationLink();


    return $user->save();
  }
}
