<?php

namespace app\models\User\Forms;

use Yii;
use app\models\User\User;
use yii\base\Model;
use yii\web\NotFoundHttpException;
use yii\helpers\Html;


// PASSWORD RESET REQUEST FORM
class PasswordResetRequestForm extends Model
{

    public $email;


    /**
     * {@inheritdoc}
     */

    /**
     * {@inheritdoc}
     */
     public function rules()
       {
           return [
               ['email', 'trim'],
               ['email', 'required'],
               ['email', 'email'],
               ['email', 'exist',
                   'targetClass' => '\app\models\User\User',
                   'filter' => ['status' => User::USER_ACTIVE],
                   'message' => 'Nu există utulizator cu acest email'
               ],
           ];
       }

       public function attributeLabels()
       {
           return [
               'email' => 'Emailul tău'
           ];
       }

       /**
        * Sends an email with a link, for resetting the password.
        *
        * @return bool whether the email was send
        */
       public function sendEmail()
       {
           /* @var $user User */
           $user = User::findOne([
               'status' => User::USER_ACTIVE,
               'email' => $this->email,
           ]);

           if (!$user) {
               return false;
           }

           if (!User::isPasswordResetTokenValid($user->password_reset_code)) {
               $user->generatePasswordResetToken();
               if (!$user->save()) {
                   return false;
               }
           }

            $confirmationLinkUrl = Yii::$app->urlManager->createAbsoluteUrl(['auth/reset-password', 'token' => $user->password_reset_code]);
            $confirmationLink = Html::a('clicking here!', $confirmationLinkUrl);

            $body = Yii::$app->view->renderFile ( '../mail/layouts/password.php' , ['confirmationLink' => $confirmationLink] );

           return Yii::$app
               ->mailer
               ->compose()
               ->setFrom([Yii::$app->params['adminEmail']])
               ->setTo($this->email)
               ->setSubject($this->email.' resetarea parolei')
               ->setHtmlBody($body)
               ->send();
       }

}
