<?php

namespace app\models\User\Forms;

use Yii;
use yii\base\Model;
use \app\models\User\User;

/**
 * LoginForm is the model behind the login form.
 *
 * @property-read User|null $user This property is read-only.
 *
 */
class UpdatePasswordForm extends Model
{
    public $userPassword;
    public $newPassword;
    public $confirmPassword;



    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            [['userPassword','newPassword', 'confirmPassword'], 'required'],
            [['userPassword','newPassword', 'confirmPassword'], 'trim'],
            [['confirmPassword'], 'compare', 'compareAttribute'=>'newPassword', 'message'=>"Parolele nu coincid"],
            [['userPassword'], 'validatePassword'],
            [['userPassword','newPassword', 'confirmPassword'], 'string', 'min' => 6, 'max' => 15]

        ];
    }

    public function attributeLabels()
    {
        return [
            'userPassword' => 'Parola actuală',
            'newPassword' => 'Parola nouă',
            'confirmPassword' => 'Confirmă parola',
        ];
    }

    public function validatePassword($attribute, $params)
    {
            $id = Yii::$app->user->id;
            $user = $this->findUser($id);
            if (!$user->validatePassword($this->userPassword)) {
              $this->addError($attribute, 'Parolă incorectă');
            }
    }

    public function save()
    {
      if($this->validate()){
        $id = Yii::$app->user->id;
        $user = $this->findUser($id);
        $user->updated_at = time();
        $user->password = Yii::$app->security->generatePasswordHash($this->newPassword);
        return $user->save();
      }
    }


    public function findUser($id)
    {
        if (($id = User::findOne($id)) !== null) {
            return $id;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }


    public function beforeValidate()
    {
      $this->newPassword = strip_tags($this->newPassword);
      return parent::beforeValidate();
    }

}
