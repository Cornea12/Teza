<?php

namespace app\models\User\Forms;

use Yii;
use \app\models\User\User;
use yii\base\Model;
use yii\db\ActiveRecord;
use yii\web\UploadedFile;
use yii\web\NotFoundHttpException;



class UserUpdateForm extends Model
{

public $firstname;
public $lastname;
    /**
     * {@inheritdoc}
     */

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['firstname', 'lastname'], 'required'],
            [['firstname', 'lastname'], 'trim'],
            [['firstname', 'lastname'], 'string', 'min' => 2, 'max' => 32],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'fistname' => 'Nume',
            'lastname' => 'Prenume',
        ];
    }


    public function save($profile)
    {

        $user = $profile;
        $user->firstname = strip_tags($this->firstname);
        $user->lastname = strip_tags($this->lastname);
        $user->updated_at = time();
        return $user->save();
    }

}
