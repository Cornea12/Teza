<?php

namespace app\models\User;

use Yii;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;

/**
 * This is the model class for table "users".
 *
 * @property int $id
 * @property string|null $firstname
 * @property string|null $lastname
 * @property string|null $email
 * @property string|null $password
 * @property string|null $auth_key
 * @property string|null $password_reset_code
 * @property string|null $email_token
 * @property int|null $status
 * @property int|null $created_at
 * @property int|null $updated_at
 *
 * @property Producer[] $producers
 * @property Producer[] $producers0
 * @property ProductCategory[] $productCategories
 * @property ProductCategory[] $productCategories0
 * @property Product[] $products
 * @property Product[] $products0
 */
class User extends ActiveRecord implements IdentityInterface
{
  CONST USER_ACTIVE = 1;
  CONST USER_INACTIVE = 0;
  CONST USER_BANED = 2;

  public $role;
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'users';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['status'], 'integer'],
            [['role'], 'safe']
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'firstname' => 'Firstname',
            'lastname' => 'Lastname',
            'email' => 'Email',
            'password' => 'Password',
            'auth_key' => 'Auth Key',
            'password_reset_code' => 'Password Reset Code',
            'email_token' => 'Email Token',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * Gets query for [[Producers]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProducers()
    {
        return $this->hasMany(Producer::className(), ['created_by' => 'id']);
    }

    /**
     * Gets query for [[Producers0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProducers0()
    {
        return $this->hasMany(Producer::className(), ['updated_by' => 'id']);
    }

    /**
     * Gets query for [[ProductCategories]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProductCategories()
    {
        return $this->hasMany(ProductCategory::className(), ['created_by' => 'id']);
    }

    /**
     * Gets query for [[ProductCategories0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProductCategories0()
    {
        return $this->hasMany(ProductCategory::className(), ['updated_by' => 'id']);
    }

    /**
     * Gets query for [[Products]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProducts()
    {
        return $this->hasMany(Product::className(), ['created_by' => 'id']);
    }

    public function saveRoles()
    {
      Yii::$app->authManager->revokeAll($this->getId());
      if ($role = Yii::$app->authManager->getRole($this->role)) {
        Yii::$app->authManager->assign($role, $this->getId());
      }
    }

    public function getRoles()
    {
      $roles = Yii::$app->authManager->getRolesByUser($this->getId());
      return ArrayHelper::getColumn($roles, 'name', false);
    }

    public function afterFind()
    {
      $this->role = $this->getRoles();
    }

    /**
     * Gets query for [[Products0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProducts0()
    {
        return $this->hasMany(Product::className(), ['updated_by' => 'id']);
    }

    public static function findIdentity($id)
        {
          return static::findOne($id);
        }

     public static function findIdentityByAccessToken($token, $type = null)
        {
          // return static::findOne(['access_token' => $token]);
        }

     public static function findByEmail($email)
     {
       return static ::findOne(['email' => $email, 'status' =>self::USER_ACTIVE]);
     }

    public function getId()
       {
        return $this->id;
       }

    public function getAuthKey()
       {
         return $this->auth_key;
       }

    public function validateAuthKey($auth_key)
       {
        return $this->auth_key === $auth_key;
       }

    public function validatePassword($password)
      {
        return Yii::$app->security->validatePassword($password, $this->password);
      }

      public static function findByPasswordResetToken($token)
  {

      if (!static::isPasswordResetTokenValid($token)) {
          return null;
      }

      return static::findOne([
          'password_reset_code' => $token,
          'status' => self::USER_ACTIVE,
      ]);
  }

    public static function isPasswordResetTokenValid($token)
      {

          if (empty($token)) {
              return false;
          }

          $timestamp = (int) substr($token, strrpos($token, '_') + 1);
          $expire = Yii::$app->params['user.passwordResetTokenExpire'];
          return $timestamp + $expire >= time();
      }

      public function generatePasswordResetToken()
      {
          $this->password_reset_code = Yii::$app->security->generateRandomString() . '_' . time();
      }

      public function removePasswordResetToken()
      {
          $this->password_reset_code = null;
      }

      public function sendConfirmationLink()
      {
         //link url generation
         $confirmationLinkUrl = Yii::$app->urlManager->createAbsoluteUrl(['/auth/confirm-email', 'email' => $this->email, 'email_token' => $this->email_token]);
         //link generation
         $confirmationLink = Html::a('faînd click aici!', $confirmationLinkUrl);

         $body = Yii::$app->view->renderFile( '../mail/layouts/verify.php' , ['confirmationLink' => $confirmationLink] );
         //Send E-mail to user for confirmation
         $sendingResult = Yii::$app->mailer->compose()
         ->setTo($this->email)
         ->setFrom(Yii::$app->params['adminEmail'])
         ->setSubject($this->email.', confirm your email address')
         ->setHtmlBody($body)
         ->send();

         return $sendingResult;
      }

}
