<?php

namespace app\models\Info;

use Yii;

/**
 * This is the model class for table "terms".
 *
 * @property int $id
 * @property string|null $title
 * @property string|null $content
 * @property int $created_at
 * @property int $updated_at
 */
class Terms extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'terms';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['content'], 'string'],
            [['content', 'title'], 'required'],
            [['created_at', 'updated_at'], 'integer'],
            [['title'], 'string', 'max' => 255],
            [['created_at'], 'default', 'value' => time()],
            [['updated_at'], 'default', 'value' => time() ],
        ];
    }



    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => 'Title',
            'content' => 'Content',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function beforeValidate()
    {
      $this->title = strip_tags($this->title);
      return parent::beforeValidate();
    }

    public static function getTerms(){
      return Terms::find()->one();
    }


    public function getDateUpdate()
    {
      return Yii::$app->formatter->asDate($this->updated_at).' '.Yii::$app->formatter->asTime($this->updated_at);
    }

    public function getDateCreate()
    {
      return Yii::$app->formatter->asDate($this->created_at).' '.Yii::$app->formatter->asTime($this->created_at);
    }
}
