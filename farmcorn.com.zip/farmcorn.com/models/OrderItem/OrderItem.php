<?php

namespace app\models\OrderItem;

use Yii;
use app\models\Product\Product;
use app\helpers\Helper;

/**
 * This is the model class for table "order_item".
 *
 * @property int $id
 * @property int|null $order_id
 * @property int|null $product_id
 * @property string|null $product_title
 * @property float|null $product_price
 * @property int|null $product_quantity
 * @property float|null $product_sum
 * @property int|null $created_at
 * @property int|null $updated_at
 */
class OrderItem extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'order_item';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['order_id', 'product_id', 'product_quantity', 'created_at', 'updated_at'], 'integer'],
            [['product_price', 'product_sum'], 'number'],
            [['product_title'], 'string', 'max' => 255],
        ];
    }


    public function getProduct()
    {
        return $this->hasOne(Product::className(), ['id' => 'product_id']);
    }

   public function saveItem($items, $order_id)
    {
      foreach ($items as $product => $item) {
        $orderItem = new OrderItem;
        $orderItem->order_id = $order_id;
        $orderItem->product_id = $item->product_id;
        $orderItem->product_quantity = $item->quantity;
        $orderItem->product_title = $item->product->title;
        $orderItem->product_price = $item->product->price;
        $orderItem->product_sum = Helper::getDiscount($item->product->price, $item->product->discount) * $item->quantity;
        $orderItem->created_at = time();
        $orderItem->updated_at = time();
        $orderItem->save();
      }
    }


    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'order_id' => 'Order ID',
            'product_id' => 'Product ID',
            'product_title' => 'Product Title',
            'product_price' => 'Product Price',
            'product_quantity' => 'Product Quantity',
            'product_sum' => 'Product Sum',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public static function findOrderItems($id)
    {
      return OrderItem::find()->where(['order_id' => $id])->all();
    }
}
