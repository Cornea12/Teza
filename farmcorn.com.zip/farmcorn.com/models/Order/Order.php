<?php

namespace app\models\Order;

use Yii;
use app\models\OrderItem\OrderItem;
use app\models\Payment\Payment;
use app\models\User\User;

/**
 * This is the model class for table "order".
 *
 * @property int $id
 * @property string|null $oreder_code
 * @property int|null $user_id
 * @property int|null $quantity
 * @property float|null $amount
 * @property string|null $firstname
 * @property string|null $lastname
 * @property string|null $email
 * @property int|null $phone
 * @property string|null $address
 * @property int|null $zip_code
 * @property int|null $payment_id
 * @property int|null $created_at
 * @property int|null $updated_at
 */
class Order extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'order';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['user_id', 'quantity', 'phone', 'zip_code', 'payment_id', 'created_at', 'updated_at'], 'integer'],
            [['amount'], 'number'],
            [['phone'], 'number', 'max'=> 999999999999, 'message' => 'Lugime maxima 12 caractere format din numere'],
            [['email'], 'email'],
            [['oreder_code', 'firstname', 'lastname', 'address'], 'string', 'min'=>2 ,'max' => 255],
            [['firstname', 'lastname', 'email', 'phone', 'zip_code','address'], 'required'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'oreder_code' => 'Codul comenzii',
            'user_id' => 'Utilizatorul',
            'quantity' => 'Cantitate',
            'amount' => 'Suma MLD',
            'firstname' => 'Nume',
            'lastname' => 'Prenume',
            'email' => 'Email',
            'phone' => 'Telefon',
            'address' => 'Adresa',
            'zip_code' => 'Cod Postal',
            'payment_id' => 'ID Plată',
            'created_at' => 'Creat',
            'updated_at' => 'Modificat',
        ];
    }

    public function getItem()
    {
        return $this->hasMany(OrderItem::className(), ['order_id' => 'id']);
    }

    public function getPayment()
    {
        return $this->hasOne(Payment::className(), ['id' => 'payment_id']);
    }

    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }


    public function saveOrderDetails($totalQty, $totalSum)
    {
      $this->oreder_code =strtoupper(Yii::$app->security->generateRandomString(10));
      $this->user_id = Yii::$app->user->identity->id;
      $this->quantity = $totalQty;
      $this->amount = $totalSum;
      $this->created_at = time();
      $this->updated_at = time();
      return $this->save();
    }

    public function addPaymentId($payment)
    {
      $this->payment_id = $payment->id;
      return $this->save();
    }

    public static function findLast()
    {
      return Order::find()->where(['user_id' => Yii::$app->user->identity->id])->orderBy('updated_at desc')->one();
    }

    public static function findOrders()
    {
      return Order::find()->where(['user_id' => Yii::$app->user->identity->id])->orderBy('updated_at desc')->all();
    }

    public static function countUserOrders()
    {
      return Order::find()->where(['user_id' => Yii::$app->user->identity->id])->count();
    }

    public function sendConfirmationOrder($order)
    {
       //link url generation

       $body = Yii::$app->view->renderFile( '../mail/layouts/order.php' , ['order' => $order] );
       //Send E-mail to user for confirmation
       $sendingResult = Yii::$app->mailer->compose()
       ->setTo($this->email)
       ->setFrom(Yii::$app->params['adminEmail'])
       ->setSubject($this->email.', Confrimare comandă')
       ->setHtmlBody($body)
       ->send();

       return $sendingResult;
    }
}
