<?php

namespace app\models\Product;



use yii\base\Model;
use app\models\Product\Product;


/**
 * CarRentModelSearch represents the model behind the search form of `app\models\CarRentModel\CarRentModel`.
 */


  class ProductFind extends Product
  {
      /**
       * {@inheritdoc}
       */
      public function rules()
      {
          return [
              [['title'], 'safe'],
          ];
      }


      public function getProductFilter($params, $limit = 2)
      {
        $this->load($params);
        $filter =  Product::find()->where(['status' => 1]);


          $filter->andWhere(['title' => $this->title]);



        $command = $filter->orderBy('updated_at desc')->limit($limit)->all();

        return $command;
      }

}
