<?php

namespace app\models\Product;

use Yii;
use yii\web\UploadedFile;
use app\models\ProductCategory\ProductCategory;
use app\models\Producer\Producer;
use app\models\User\User;
use app\helpers\Helper;

/**
 * This is the model class for table "product".
 *
 * @property int $id
 * @property string|null $name
 * @property string|null $description
 * @property float|null $price
 * @property int|null $stock
 * @property float|null $discount
 * @property string|null $image
 * @property int|null $category_id
 * @property int|null $producer_id
 * @property int|null $status
 * @property int|null $created_by
 * @property int|null $updated_by
 * @property int|null $created_at
 * @property int|null $updated_at
 *
 * @property ProductCategory $category
 * @property Users $createdBy
 * @property Producer $producer
 * @property Users $updatedBy
 */
class Product extends \yii\db\ActiveRecord
{

   public $path = 'images/product-img/';
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'product';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'description', 'price', 'stock', 'discount','dosage','measure_type', 'category_id', 'producer_id', 'status'], 'required'],
            [['name', 'description', 'price', 'stock', 'discount', 'dosage','measure_type', 'category_id', 'producer_id', 'status'], 'trim'],
            [['description'], 'string', 'min' => 50],
            [['price', 'discount'], 'number'],
            [['name'], 'string', 'max' => 100],
            [['image'], 'image', 'extensions' => 'jpg,jpeg,gif,webp,png,svg'],
            [['stock', 'category_id', 'producer_id', 'status', 'created_by', 'updated_by', 'created_at', 'updated_at'], 'integer'],
            [['category_id'], 'exist', 'skipOnError' => true, 'targetClass' => ProductCategory::className(), 'targetAttribute' => ['category_id' => 'id']],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['created_by' => 'id']],
            [['producer_id'], 'exist', 'skipOnError' => true, 'targetClass' => Producer::className(), 'targetAttribute' => ['producer_id' => 'id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['updated_by' => 'id']],
            [['created_by', 'updated_by'], 'default', 'value' => Yii::$app->user->identity->id],
            [['created_at', 'updated_at'], 'default', 'value' => time()],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => 'Titlu',
            'name' => 'Denumire produs',
            'description' => 'Descriere produs',
            'price' => 'Preț',
            'stock' => 'Stock',
            'dosage' => 'Doza',
            'measure_type' => 'Unitate de masura',
            'discount' => 'Reducere',
            'image' => 'Imagine format .JPG, .JPEG, .PNG, .WEBP, .SVG, .PNG, .GIF',
            'category_id' => 'Categoria',
            'producer_id' => 'Producătorul',
            'status' => 'Statut',
            'created_by' => 'Creat de',
            'updated_by' => 'Modificat de',
            'created_at' => 'Creat la data',
            'updated_at' => 'Actualizat la data',
        ];
    }


    public function beforeValidate()
    {
      $this->name = strip_tags($this->name);
      // $this->description = strip_tags($this->description);
      $this->dosage = strip_tags($this->dosage);
      $this->measure_type = strip_tags($this->measure_type);
      $this->price = strip_tags($this->price);
      $this->stock = strip_tags($this->stock);
      $this->discount = strip_tags($this->discount);
      $this->category_id = strip_tags($this->category_id);
      $this->producer_id = strip_tags($this->producer_id);
      $this->status = strip_tags($this->status);

      return parent::beforeValidate();

    }

    /**
     * Gets query for [[Category]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCategory()
    {
        return $this->hasOne(ProductCategory::className(), ['id' => 'category_id']);
    }

    /**
     * Gets query for [[CreatedBy]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'created_by']);
    }

    /**
     * Gets query for [[Producer]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProducer()
    {
        return $this->hasOne(Producer::className(), ['id' => 'producer_id']);
    }

    /**
     * Gets query for [[UpdatedBy]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'updated_by']);
    }

    public function setUrl()
    {
      $this->url =  Helper::createUrl($this->createTitle(), $this->url);
      return $this->save();
    }

    public function setTitle()
    {
      $this->createTitle();
      return $this->save();
    }

    public function createTitle()
    {
     return  $this->title = Helper::createTitle($this->name.' '.$this->dosage.''.$this->measure_type.', '.$this->category->name);
    }

    public function beforeDelete()
    {
        Helper::deleteImage($this->path.Yii::getAlias('@web'),$this->image);
        return parent::beforeDelete(); // TODO: Change the autogenerated stub
    }

    public function uploadFile($model, $oldImg = null)
    {

      $image = UploadedFile::getInstance($model,'image');
      if ($image)
      {
        Helper::deleteImage(Yii::getAlias('@web').$this->path, $oldImg);
        $this->image = Helper::saveImageAs($image, Yii::getAlias('@web').$this->path);
      }
      else
      {
        $this->image = $oldImg;
      }
   return $this->save();
    }

    public function updateData()
    {
      $this->updated_at = time();
      $this->setTitle();
      $this->setUrl();
      $this->updated_by = Yii::$app->user->identity->id;

      return $this->save();
    }

    public static function getAllProducts($limit)
    {
      return Product::find()->with('producer')->where(['status' => 1])->orderBy('updated_at desc')->limit($limit)->all();
    }

   public static function getMostViewed()
   {
     return Product::find()->where(['status' => 1])->orderBy('updated_at desc')->limit(6)->all();
   }

   public static function getDiscount()
   {
     return Product::find()->where(['status' => 1])->andWhere(['>', 'discount', 0])->orderBy('updated_at desc')->limit(6)->all();
   }

   public static function findCart($id)
   {
     return Product::find()->where(['id' => $id])->andWhere(['status' => 1])->andWhere(['>', 'stock', 0 ])->one();
   }

   public static function getProductSearch()
   {
     return Product::find()->where(['status' => 1])->orderBy('updated_at desc')->all();
   }
}
