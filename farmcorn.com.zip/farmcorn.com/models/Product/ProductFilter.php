<?php

namespace app\models\Product;



use yii\base\Model;
use app\models\Product\Product;


/**
 * CarRentModelSearch represents the model behind the search form of `app\models\CarRentModel\CarRentModel`.
 */


  class ProductFilter extends Product
  {
      /**
       * {@inheritdoc}
       */
      public function rules()
      {
          return [
              [['category_id', 'producer_id', 'discount', 'price'], 'safe'],
          ];
      }


      public function getProductFilter($params, $limit = 2)
      {
        $this->load($params);
        $filter =  Product::find()->where(['status' => 1]);

          if($this->category_id){
          $filter->andWhere(['category_id' => $this->category_id]);
        }

        if($this->producer_id){
          $filter->andWhere(['producer_id' => $this->producer_id]);
        }

       if($this->discount){
          $filter->andWhere(['>','discount' , 0]);
       }

        if($this->price){
           $filter->andWhere(['<=','price' , $this->price]);
         }



        $command = $filter->orderBy('updated_at desc')->limit($limit)->all();

        return $command;
      }

}
