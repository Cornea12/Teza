<?php

namespace app\models\Payment\Forms;

use Yii;

/**
 * This is the model class for table "payments".
 *
 * @property int $id
 * @property int|null $transfer_code
 * @property int|null $client_id
 * @property int|null $amount
 * @property int|null $status
 * @property int|null $created_at
 * @property int|null $updated_at
 *
 * @property Reservation[] $reservations
 */
class CardForm extends \yii\db\ActiveRecord
{
    public $card_number;
    public $owner;
    public $expiration;
    public $cvv;


    public function rules()
    {
        return [
            [['card_number','owner', 'expiration', 'cvv'], 'required'],
            [['card_number','owner', 'expiration', 'cvv'], 'trim'],
            [['card_number'], 'string', 'min' =>16,  'max'=>16],
            [['owner'], 'string', 'min' =>2,  'max'=>20],
            [['cvv'], 'integer', 'min'=>000, 'max' => 999],
        ];
    }

    /**
     * {@inheritdoc}
     */

}
