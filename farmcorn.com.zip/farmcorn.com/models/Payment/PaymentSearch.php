<?php

namespace app\models\Payment;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Payment\Payment;

/**
 * PaymentSearch represents the model behind the search form of `app\models\Payment\Payment`.
 */
class PaymentSearch extends Payment
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'order_id', 'user_id', 'payment_at_deliver', 'status', 'admin_id_update', 'created_at', 'updated_at'], 'integer'],
            [['payment_code'], 'safe'],
            [['amount'], 'number'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Payment::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'order_id' => $this->order_id,
            'user_id' => $this->user_id,
            'amount' => $this->amount,
            'payment_at_deliver' => $this->payment_at_deliver,
            'status' => $this->status,
            'admin_id_update' => $this->admin_id_update,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ]);

        $query->andFilterWhere(['like', 'payment_code', $this->payment_code]);

        return $dataProvider;
    }
}
