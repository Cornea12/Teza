<?php

namespace app\models\Payment;

use Yii;

/**
 * This is the model class for table "payment".
 *
 * @property int $id
 * @property string|null $payment_code
 * @property int|null $order_id
 * @property int|null $user_id
 * @property float|null $amount
 * @property int|null $payment_at_deliver
 * @property int|null $status
 * @property int|null $admin_id_update
 * @property int|null $created_at
 * @property int|null $updated_at
 */
class Payment extends \yii\db\ActiveRecord
{

    CONST PAY_SUCCESS = 1;
    CONST PAY_FAIL = 0;
    CONST PAY_PENDING = 2;
    CONST PAY_ONLINE = 0;
    CONST PAY_CASH = 1;
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'payment';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['order_id', 'user_id', 'payment_at_deliver', 'status', 'admin_id_update', 'created_at', 'updated_at'], 'integer'],
            [['amount'], 'number'],
            [['payment_code'], 'string', 'max' => 255],
        ];
    }


    public function savePayment($order)
    {
      $this->order_id = $order->id;
      $this->payment_code = strtoupper(Yii::$app->security->generateRandomString(10));
      $this->user_id = Yii::$app->user->identity->id;
      $this->amount = $order->amount;
      $this->created_at = time();
      $this->updated_at = time();
    }

    public function payOnline($order)
    {
       $this->savePayment($order);
       $this->payment_at_deliver = self::PAY_ONLINE;
       $this->status = self::PAY_SUCCESS;
       return $this->save();
    }

    public function payCash($order)
    {
       $this->savePayment($order);
       $this->payment_at_deliver = self::PAY_CASH;
       $this->status = self::PAY_PENDING;
       return $this->save();
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'payment_code' => 'Codul plății',
            'order_id' => 'ID comenzii',
            'user_id' => 'Utilizator',
            'amount' => 'Suma MLD',
            'payment_at_deliver' => 'Plata la domiciliu',
            'status' => 'Statut',
            'admin_id_update' => 'Modificat de',
            'created_at' => 'Creat la:',
            'updated_at' => 'Modificat la:',
        ];
    }
}
