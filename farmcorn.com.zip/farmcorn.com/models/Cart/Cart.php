<?php

namespace app\models\Cart;

use Yii;
use app\models\Product\Product;
use app\models\User\User;

/**
 * This is the model class for table "cart".
 *
 * @property int $id
 * @property int|null $product_id
 * @property string|null $title
 * @property int|null $quantity
 * @property float|null $price
 * @property string|null $image
 * @property string|null $path
 * @property int|null $user_id
 * @property int|null $created_at
 * @property int|null $updated_at
 *
 * @property Product $product
 * @property Users $user
 */
class Cart extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'cart';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['product_id', 'quantity', 'user_id', 'created_at', 'updated_at'], 'integer'],
            [['product_id'], 'exist', 'skipOnError' => true, 'targetClass' => Product::className(), 'targetAttribute' => ['product_id' => 'id']],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['user_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'product_id' => 'Product ID',
            'title' => 'Title',
            'quantity' => 'Quantity',
            'price' => 'Price',
            'image' => 'Image',
            'path' => 'Path',
            'user_id' => 'User ID',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * Gets query for [[Product]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProduct()
    {
        return $this->hasOne(Product::className(), ['id' => 'product_id']);
    }

    /**
     * Gets query for [[User]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }

    public function addCartUser($product, $id)
    {
      $item = $this->findCartOne($id);
      if ($item) {
        $item->quantity++;
        return $item->save();
      }
      else
      {
        $this->product_id = $product->id;
        $this->quantity = 1;
        $this->user_id = Yii::$app->user->identity->id;
        $this->created_at = time();
        $this->updated_at = time();
      }


      return $this->save();

    }

    public function updateQty($id, $qty)
    {
      $item = $this->findCartOne($id);
      if ($item) {
        $item->quantity = $qty;
        return $item->save();
      }
      else {
        return false;
      }
    }

    public function deleteItems($userCart)
    {
      foreach ($userCart as $cart)
      {
        $cart->delete();
      }
    }

    public function checkCart($id)
    {
       return Cart::find()->where(['product_id' => $id])->andWhere(['user_id'=> Yii::$app->user->identity->id])->one();
    }

    public static function showCart()
    {
      return Cart::find()->where(['user_id'=> Yii::$app->user->identity->id])->all();
    }

    public static function findCartOne($id)
    {
      return Cart::find()->where(['user_id'=> Yii::$app->user->identity->id, 'product_id' => $id])->one();
    }


    public static function cartQtySum()
    {
      return Cart::find()->where(['user_id'=> Yii::$app->user->identity->id])->sum('quantity');
    }

    public static function cartPriceSum()
    {
      return Cart::find()->where(['user_id'=> Yii::$app->user->identity->id])->sum('total_price');
    }


}
