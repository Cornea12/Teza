<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;
use app\helpers\Helper;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Categoriile Produselor';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="product-category-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Adaugă Categorie', ['create'], ['class' => 'btn btn-success']) ?>
    </p>


    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'name',
            [
              'attribute' => 'status',
              'format' => 'html',
              'value' => function($model)
              {
                return Html::tag('b',Helper::getStatus($model->status));
              }
            ],
            [
              'attribute' => 'updated_by',
              'format' => 'html',
              'value' => function($model)
              {
                return Html::tag('p',Helper::getValue($model->updatedBy->firstname.' '.$model->updatedBy->lastname));
              }
            ],
            [
              'attribute' => 'updated_at',
              'format' => 'html',
              'value' => function($model)
              {
                return Html::tag('p',Helper::getDate($model->updated_at));
              }
            ],
            //'created_at',
            //'updated_at',
            [
                'class' => ActionColumn::className(),
                'urlCreator' => function ($action, \app\models\ProductCategory\ProductCategory $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'id' => $model->id]);
                 }
            ],
        ],
    ]); ?>


</div>
