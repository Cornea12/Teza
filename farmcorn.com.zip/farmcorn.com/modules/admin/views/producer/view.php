<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use app\helpers\Helper;

/* @var $this yii\web\View */
/* @var $model app\models\ProductCategory\ProductCategory */

$this->title = $model->name;
$this->params['breadcrumbs'][] = ['label' => 'Categorie', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="product-category-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Actualizare', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Șterge', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Ești sigur că vrei să elimini acest item?',
                'method' => 'post',
            ],
        ]) ?>
        <?= Html::a('Adaugă', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'name',
            [
              'attribute' => 'status',
              'format' => 'html',
              'value' => Html::tag('b',Helper::getStatus($model->status))
            ],
            [
              'attribute' => 'created_by',
              'format' => 'html',
              'value' => Html::tag('p',Helper::getValue($model->createdBy->firstname.' '.$model->updatedBy->lastname))
            ],
            [
              'attribute' => 'updated_by',
              'format' => 'html',
              'value' => Html::tag('p',Helper::getValue($model->updatedBy->firstname.' '.$model->updatedBy->lastname))
            ],
            [
              'attribute' => 'created_at',
              'format' => 'html',
              'value' => Html::tag('p',Helper::getDate($model->created_at))
            ],
            [
              'attribute' => 'updated_at',
              'format' => 'html',
              'value' => Html::tag('p',Helper::getDate($model->updated_at))
            ],
        ],
    ]) ?>

</div>
