<?php

use yii\helpers\Html;
use app\helpers\Helper;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Producători';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="producer-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Adaugă', ['create'], ['class' => 'btn btn-success']) ?>
    </p>


    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'name',
            [
              'attribute' => 'status',
              'format' => 'html',
              'value' => function($model)
              {
                return Html::tag('b',Helper::getStatus($model->status));
              }
            ],
            [
              'attribute' => 'updated_by',
              'format' => 'html',
              'value' => function($model)
              {
                return Html::tag('p',Helper::getValue($model->updatedBy->firstname.' '.$model->updatedBy->lastname));
              }
            ],
            [
              'attribute' => 'updated_at',
              'format' => 'html',
              'value' => function($model)
              {
                return Html::tag('p',Helper::getDate($model->updated_at));
              }
            ],
            //'created_at',
            //'updated_at',
            [
                'class' => ActionColumn::className(),
                'urlCreator' => function ($action, \app\models\Producer\Producer $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'id' => $model->id]);
                 }
            ],
        ],
    ]); ?>


</div>
