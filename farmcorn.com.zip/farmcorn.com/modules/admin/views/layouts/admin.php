<?php

/** @var \yii\web\View $this */
/** @var string $content */

use app\widgets\Alert;
use app\assets\AdminAsset;
use yii\bootstrap4\Breadcrumbs;
use yii\bootstrap4\Html;
use yii\bootstrap4\Nav;
use yii\bootstrap4\NavBar;
use yii\helpers\Url;

AdminAsset::register($this);

?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>" class="h-100">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php $this->registerCsrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body class="d-flex flex-column h-100">
<?php $this->beginBody() ?>

<div class="wrap">
  <div class="navigation">
    <header class="admin-header">
        <div class="admin-col">
          <div class="logo"> <a href="<?= Url::toRoute(['/']);?>">Admin Panel</a></div>
          <div class="admin-photo">
            <img src="https://st4.depositphotos.com/1012074/20946/v/450/depositphotos_209469984-stock-illustration-flat-isolated-vector-illustration-icon.jpg" alt="admin profile image">
          </div>
          <div class="admin-username"><?=Yii::$app->user->identity->email ?></div>
          <nav class="admin-menu">
              <ul class="admin-list">
                <li><a href="<?= Url::toRoute(['/admin/product']);?>"><span>Produse</span></a> </li>
                <li><a href="<?= Url::toRoute(['/admin/producer']);?>"><span>Producători</span></a> </li>
                <li><a href="<?= Url::toRoute(['/admin/product-category']);?>"><span>Categorie produse</span></a> </li>
                <li><a href="<?= Url::toRoute(['/admin/order']);?>"><span>Comenzi</span></a> </li>
                <li><a href="<?= Url::toRoute(['/admin/payment']);?>"><span>Plăți</span></a> </li>
                <li><a href="<?= Url::toRoute(['/admin/user']);?>"><span>Utilizatori</span></a> </li>
                <li><a href="<?= Url::toRoute(['/admin/about-us']);?>"><span>Despre noi</span></a> </li>
                <li><a href="<?= Url::toRoute(['/admin/terms']);?>"><span>Termeni</span></a> </li>
              </ul>
            </nav>
          </div>
    </header>
<div class="cont">
  <div class="admin-nav">
    <div class="admin-icon">
      <span><i class="fa fa-bars" aria-hidden="true"></i></span>
    </div>
      <?php if (!Yii::$app->user->isGuest): ?>
        <?= Html::beginForm(['/auth/logout'], 'post') ?>
        <?= Html::submitButton('Logout' ,['class' => 'admin-logout']) ?>
        <?= Html::endForm() ?>
      <?php endif; ?>
  </div>
  <div class="page-actions">
    <?= Breadcrumbs::widget([
      'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
      'options' => [],
  ]); ?>
  <?= Alert::widget() ?>
    <?= $content ?>
  </div>
</div>

  </div>
</div>

<!-- <footer class="footer mt-auto py-3 text-muted">
    <div class="container">
        <p class="float-left">&copy; <?= Html::encode(Yii::$app->name) ?> <?= date('Y') ?></p>
        <p class="float-right"><?= Yii::powered() ?></p>
    </div>
</footer> -->

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage();
