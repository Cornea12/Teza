<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;
use app\helpers\Helper;

/* @var $this yii\web\View */
/* @var $searchModel app\models\Product\ProductSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Produse';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="product-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Adaugă', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'title',
            'price',
            'stock',
            [
              'label' => 'image',
              'format' => 'html',
              'value' => function($model)
              {
                return Html::img(Helper::getImage($model->path, $model->image), ['class' => 'admin-img-view']);
              }
            ],
            [
                'class' => ActionColumn::className(),
                'urlCreator' => function ($action, \app\models\Product\Product $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'id' => $model->id]);
                 }
            ],
        ],
    ]); ?>


</div>
