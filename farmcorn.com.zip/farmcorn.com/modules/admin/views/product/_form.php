<?php

use yii\helpers\Html;
use yii\bootstrap4\ActiveForm;
use yii\helpers\ArrayHelper;
use app\models\ProductCategory\ProductCategory;
use app\models\Producer\Producer;
use mihaildev\ckeditor\CKEditor;

/* @var $this yii\web\View */
/* @var $model app\models\Product\Product */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="product-form">

    <?php $form = ActiveForm::begin(['options' => [
      'enctype' => 'multipart/form-data'
      ]]); ?>

    <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'description')->widget(CKEditor::className(),[
        'editorOptions' => [
        'preset' => 'full', //разработанны стандартные настройки basic, standard, full данную возможность не обязательно использовать
        'inline' => false, //по умолчанию false
    ],
]); ?>

    <?= $form->field($model, 'dosage')->textInput() ?>

    <?= $form->field($model, 'measure_type')->textInput() ?>

    <?= $form->field($model, 'price')->textInput() ?>

    <?= $form->field($model, 'stock')->textInput() ?>

    <?= $form->field($model, 'discount')->textInput() ?>

    <?= $form->field($model, 'category_id')->dropdownList(ArrayHelper::map(ProductCategory::find()->all(), 'id', 'name'),['prompt'=>'Selectează categoria']); ?>

    <?= $form->field($model, 'producer_id')->dropdownList(ArrayHelper::map(Producer::find()->all(), 'id', 'name'),['prompt'=>'Selectează prodcuătorul']); ?>

    <?= $form->field($model, 'image')->fileInput() ?>

    <?= $form->field($model, 'status')->dropdownList([0 => 'INACTIV', 1 => 'ACTIV'],['prompt'=>'Selectează statutul']) ?>


    <div class="form-group">
        <?= Html::submitButton('Salvare', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>

<form class="" enctype="multipart/form-data" action="index.html" method="post">

</form>
