<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use app\helpers\Helper;

/* @var $this yii\web\View */
/* @var $model app\models\Product\Product */

$this->title = $model->name;
$this->params['breadcrumbs'][] = ['label' => 'Produse', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="product-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Actualizare', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Șterge', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
        <?= Html::a('Adaugă', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'title',
            'name',
            // 'description:ntext',
            'price',
            'stock',
            'discount',
            [
              'label' => 'image',
              'format' => 'html',
              'value' => Html::img(Helper::getImage($model->path, $model->image), ['class' => 'admin-img-view'])
            ],
            [
              'attribute' => 'category_id',
              'format' => 'html',
              'value' => Html::tag('p',Helper::getValue($model->category->name))
            ],
            [
              'attribute' => 'producer_id',
              'format' => 'html',
              'value' => Html::tag('p',Helper::getValue($model->producer->name))
            ],
            [
              'attribute' => 'status',
              'format' => 'html',
              'value' => Html::tag('b',Helper::getStatus($model->status))
            ],
            [
              'attribute' => 'created_by',
              'format' => 'html',
              'value' => Html::tag('p',Helper::getValue($model->createdBy->firstname.' '.$model->updatedBy->lastname))
            ],
            [
              'attribute' => 'updated_by',
              'format' => 'html',
              'value' => Html::tag('p',Helper::getValue($model->updatedBy->firstname.' '.$model->updatedBy->lastname))
            ],
            [
              'attribute' => 'created_at',
              'format' => 'html',
              'value' => Html::tag('p',Helper::getDate($model->created_at))
            ],
            [
              'attribute' => 'updated_at',
              'format' => 'html',
              'value' => Html::tag('p',Helper::getDate($model->updated_at))
            ],
        ],
    ]) ?>

</div>
