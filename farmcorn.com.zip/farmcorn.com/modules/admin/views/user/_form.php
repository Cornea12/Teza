<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\User\User */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="user-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'status')->dropdownList([
      '1' => 'Activ',
      '2' => 'Ban',
    '0' => 'Inactiv',],
      ['prompt' => 'Selectează statutul']) ?>

    <?= $form->field($model, 'role')->dropdownList([
      'admin' => 'Administrator',
      'moderator' => 'Moderator',],
      ['prompt' => 'Selectează rolul']) ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
