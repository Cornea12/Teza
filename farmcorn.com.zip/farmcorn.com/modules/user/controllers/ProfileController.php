<?php

namespace app\modules\user\controllers;

use Yii;
use yii\web\Controller;
use app\helpers\Helper;
use app\models\Order\Order;
use app\models\OrderItem\OrderItem;

/**
 * Default controller for the `user` module
 */
class ProfileController extends Controller
{
    /**
     * Renders the index view for the module
     * @return string
     */
    public function actionIndex()
    {
       $lastOrder = Order::findLast();
       $countOrders = Order::countUserOrders();
       if (!empty($lastOrder)) {
         $orderItems = OrderItem::findOrderItems($lastOrder->id);
       }else {
         $orderItems = null;
       }
        return $this->render('index',[
          'lastOrder' => $lastOrder,
          'orderItems' => $orderItems,
          'countOrders' => $countOrders
        ]);
    }

    public function actionOrders()
    {
        $orders= Order::findOrders();
        return $this->render('orders',[
          'orders' => $orders,
        ]);
    }


}
