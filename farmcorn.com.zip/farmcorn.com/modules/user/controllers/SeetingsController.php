<?php

namespace app\modules\user\controllers;

use Yii;
use \app\models\User\User;
use app\models\User\forms\UserUpdateForm;
use app\models\User\forms\UpdatePasswordForm;
use yii\web\NotFoundHttpException;
use yii\web\Controller;

/**
 * Default controller for the `user` module
 */
class SeetingsController extends Controller
{
    /**
     * Renders the index view for the module
     * @return string
     */



    public function actionIndex()
    {

      if (Yii::$app->user->isGuest) {
          return $this->goHome();
      }

      $id = Yii::$app->user->id;
      $model = $this->findModel($id);
      $updateForm = new UserUpdateForm();
      $pass =  new UpdatePasswordForm;


      return $this->render('index',[
        'model' => $model,
        'updateForm' =>$updateForm,
        'pass' => $pass,
      ]);
    }


    public function actionUpdate()
    {

      $model = new UserUpdateForm;

      $id = Yii::$app->user->id;
      if ($model->load(Yii::$app->request->post()) && $model->save($this->findModel($id))) {
         Yii::$app->session->setFlash('success', 'Setari modificate cu success');
         return $this->redirect(Yii::$app->request->referrer);
      }
      else{
         Yii::$app->session->setFlash('error', 'Server error');
      }
    }


    public function actionPassword()
    {
      $model = new UpdatePasswordForm;

      if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
        Yii::$app->response->format = yii\web\Response::FORMAT_JSON;
        return \yii\widgets\ActiveForm::validate($model);
    }

      if ($model->load(Yii::$app->request->post()) && $model->save()) {
        Yii::$app->session->setFlash('success', 'Parola modificată cu success');
        return $this->redirect(Yii::$app->request->referrer);
      }
      else{
         Yii::$app->session->setFlash('error', 'Server error');
      }
    }

    protected function findModel($id)
    {
        if (($model = User::findOne($id)) !== null) {
            return $model;
        }
        throw new NotFoundHttpException('The requested page does not exist.');
    }


}
