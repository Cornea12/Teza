<?php

namespace app\modules\user;
use yii\filters\AccessControl;
use yii\filters\VerbFilter;

/**
 * user module definition class
 */
class Module extends \yii\base\Module
{

  public function behaviors(){
  return [
      'access' => [
          'class' => \yii\filters\AccessControl::className(),
          'rules' => [
              [
                  'allow' => true,
                  'roles' => ['@'],
              ],
          ],
      ],
  ];
}
    /**
     * {@inheritdoc}
     */
    public $controllerNamespace = 'app\modules\user\controllers';

    /**
     * {@inheritdoc}
     */
    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
