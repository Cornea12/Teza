<?php

use yii\helpers\Html;
use yii\helpers\Url;
use app\helpers\Helper;

$this->title = 'Comenzile Mele';
?>

<div class="container">
  <div class="profile-elements">
    <ul class="action-list">
      <li><a href="/user/profile/index">Panou de bord</a></li>
      <li><a href="/user/profile/orders">Comenzi</a></li>
      <li><a href="/cart/index">Coșul meu</a></li>
      <li><a href="/user/seetings">Setări</a></li>
    </ul>
    <div class="profile-items">
      <div class="last-order">
       <?php if ($orders): ?>
         <div class="title">Comenizle mele</div>
     <?php foreach ($orders as $order): ?>
       <?php $orderItems = $order->item; ?>
       <div class="cart-user">
       <div class="order-data">
         <h3 class="date it">Comandă efectuată pe data de: <?=Helper::date($order->created_at)?></h3>
         <h4 class="code it">Codul comenzii: <?=Html::encode($order->oreder_code)?> </h4>
         <h4 class="code it">Codul tranzacției: <?=Html::encode($order->payment->payment_code)?> </h4>
         <h4 class="code it">Suma: <?=Html::encode($order->amount)?> MLD, Cantitate: <?=Html::encode($order->quantity)?> </h4>
       </div>
         <table class="cart-page-table">
           <thead>
             <tr>
               <th>Imagine</th>
               <th>Denumire</th>
               <th>Preț</th>
               <th>Unitați</th>
               <th>Preț total</th>
             </tr>
           </thead>
           <?php foreach ($orderItems as $cart): ?>
           <tr>
               <?php if ($cart->product !== null): ?>
                 <td> <img class="it-img" src="<?=Helper::getImage($cart->product->path, $cart->product->image)?>" alt=""></td>
                 <td><?= Html::encode($cart->product_title)?></td>
                 <td><?= $cart->product_quantity?></td>
                 <td><?= $cart->product_price?></td>
                 <td><?= $cart->product_sum?> MLD</td>
                 <?php else: ?>
                   <td> <img class="it-img"src="<?=Helper::getImage('images', '\noimage.png')?>" alt=""></td>
                   <td><?= Html::encode($cart->product_title)?></td>
                   <td><?= $cart->product_quantity?></td>
                   <td><?= $cart->product_price?></td>
                   <td><?= $cart->product_sum?> MLD</td>
               <?php endif; ?>

           </tr>
           <?php endforeach; ?>
           <tr>
             <th></th>
             <th></th>
             <th></th>
             <th>Unitați total</th>
             <th>Preț total</th>
           </tr>
           <tr class="tb-totals">
               <td></td>
               <td></td>
               <td></td>
               <td><?= Html::encode($order->quantity)?></td>
               <td><?= Html::encode(round($order->amount))?> MLD</td>
               <td></td>
           </tr>
         </table>
       </div>
     <?php endforeach; ?>
       <?php else: ?>
        <h2 style="margin-top:100px;">Încă nu ai nici o comandă</h2>
       <?php endif; ?>
      </div>
    </div>
  </div>
</div>
