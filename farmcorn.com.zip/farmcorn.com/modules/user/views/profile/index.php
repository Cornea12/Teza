<?php

use yii\helpers\Html;
use yii\helpers\Url;
use app\helpers\Helper;

$this->title = "Profilul meu";

?>





<div class="container">
  <div class="profile-elements">
    <ul class="action-list">
      <li><a href="/user/profile/index">Panou de bord</a></li>
      <li><a href="/user/profile/orders">Comenzi</a></li>
      <li><a href="/cart/index">Coșul meu</a></li>
      <li><a href="/user/seetings">Setări</a></li>
    </ul>
    <div class="profile-items">
      <div class="profile-info">
        <img src="..\images\noimage.png" alt="">
        <div class="info">
          <div class="name">Salut, <?=Html::encode(Yii::$app->user->identity->firstname). ' ' .Html::encode(Yii::$app->user->identity->lastname) ?></div>
          <div class="email"><?= Html::encode(Yii::$app->user->identity->email) ?></div>
          <div class="since">Înregistrat din <?= Helper::date(Yii::$app->user->identity->created_at) ?></div>
          <div class="total-orders"> Total comenzi: <?= $countOrders ?></div>
        </div>
      </div>
      <?php if ($lastOrder): ?>
        <div class="last-order">
          <div class="title">Ultima Comandă</div>
          <div class="cart-user">
            <div class="order-data">
              <h3 class="date it">Comandă efectuată pe data de: <?=Helper::date($lastOrder->created_at)?></h3>
              <h4 class="code it">Codul comenzii: <?=Html::encode($lastOrder->oreder_code)?> </h4>
              <h4 class="code it">Codul tranzacției: <?=Html::encode($lastOrder->payment->payment_code)?> </h4>
              <h4 class="code it">Suma: <?=Html::encode($lastOrder->amount)?> MLD, Cantitate: <?=Html::encode($lastOrder->quantity)?> </h4>
            </div>
            <table class="cart-page-table">
              <thead>
                <tr>
                  <th>Imagine</th>
                  <th>Denumire</th>
                  <th>Preț</th>
                  <th>Unitați</th>
                  <th>Preț total</th>
                </tr>
              </thead>
              <?php foreach ($orderItems as $cart): ?>
              <tr>
                  <?php if ($cart->product != null): ?>
                    <td> <img class="it-img" src="<?=Helper::getImage($cart->product->path, $cart->product->image)?>" alt=""></td>
                    <td><?= Html::encode($cart->product_title)?></td>
                    <td><?= $cart->product_quantity?></td>
                    <td><?= $cart->product_price?></td>
                    <td><?= $cart->product_sum?> MLD</td>
                    <?php else: ?>
                      <td> <img class="it-img" src="<?=Helper::getImage('images', '\noimage.png')?>" alt=""> </td>
                      <td><?= Html::encode($cart->product_title)?></td>
                      <td><?= $cart->product_quantity?></td>
                      <td><?= $cart->product_price?></td>
                      <td><?= $cart->product_sum?> MLD</td>
                  <?php endif; ?>

              </tr>
              <?php endforeach; ?>
              <tr>
                <th></th>
                <th></th>
                <th></th>
                <th>Unitați total</th>
                <th>Preț total</th>
              </tr>
              <tr class="tb-totals">
                  <td></td>
                  <td></td>
                  <td></td>
                  <td><?= Html::encode($lastOrder->quantity)?></td>
                  <td><?= Html::encode(round($lastOrder->amount))?> MLD</td>
                  <td></td>
              </tr>
            </table>
          </div>
        </div>
        <?php else: ?>
          <h2 style="margin-top:100px;">Încă nu ai nici o comandă</h2>
      <?php endif; ?>
    </div>
  </div>
</div>
