<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;

$this->title = 'Setari profil: '. $model->firstname;
?>


<div class="user-page">
  <div class="initials">
    <div class="profile-container">
      <div class="initials-row">
        <?php if (Yii::$app->session->hasFlash('success')): ?>
        <div class="updated-flash"><?= Yii::$app->session->getFlash('success') ?></div>
        <?php endif; ?>
        <?php if (Yii::$app->session->hasFlash('error')): ?>
        <div class="updated-flash-error"><?= Yii::$app->session->getFlash('error') ?></div>
        <?php endif; ?>
       <div class="profile-settings">
         <div class="profile-actions">
           <div class="profile-action-title">Setări Profil</div>
           <div class="profile-update"><i class="fa fa-pencil change-data" aria-hidden="true"></i></div>
         </div>
        <div class="user-detail">
          <div class="userinfo"><span class="profile-db">Nume:</span><span class="user-db"><?= $model->firstname?></span></div>
          <div class="userinfo"><span class="profile-db">Prenume:</span><span class="user-db"><?= $model->lastname?></span></div>
          <div class="userinfo"><span class="profile-db">Email:</span><span class="user-db"><?= $model->email ?></span></div>
        </div>
        <?php $form = ActiveForm::begin([
          'options' => ['class' => 'user-setting hide'],
          'action' => ['seetings/update'],
          'enableAjaxValidation' => false,
          'fieldConfig' => [
              'errorOptions' => ['class' => 'error'],
          ]
        ]); ?>
        <?= $form->field($updateForm, 'firstname')->textInput(['value'=> $model->firstname]) ?>
        <?= $form->field($updateForm, 'lastname')->textInput(['value'=> $model->lastname]) ?>
        <?= Html::submitButton('Modifică') ?>
        <?php ActiveForm::end(); ?>
        <div class="password-settings">
          <div class="profile-actions">
            <div class="password-action-title">Setări Parola</div>
            <div class="password-update"><i class="fa fa-cogs change-pass" aria-hidden="true"></i></div>
          </div>
          <?php $form = ActiveForm::begin([
            'options' => ['class' => 'pass-update hide'],
            'action' => ['seetings/password'],
            'enableAjaxValidation' => true,
            'fieldConfig' => [
                'errorOptions' => ['class' => 'error'],
            ]
          ]); ?>
           <?= $form->field($pass, 'userPassword')->passwordInput() ?>
           <?= $form->field($pass, 'newPassword')->passwordInput() ?>
           <?= $form->field($pass, 'confirmPassword')->passwordInput() ?>
           <?= Html::submitButton('Update') ?>
           <?php ActiveForm::end(); ?>
        </div>
        <div class="password-settings">
          <div class="profile-actions">
            <div class="password-action-title">Parola Uitată</div>
            <div class="password-update"><a href="<?= Url::toRoute(['auth/request-password-reset']);?>"><i class="fa fa-cogs change-pass" aria-hidden="true"></i></a></div>
          </div>
        </div>
        <div class="saved-settings">
          <div class="profile-actions">
            <div class="profile-action-title">Coșul Meu</div>
            <div class="saved-view"><a href="<?= Url::toRoute(['/cart/index']);?>"><i class="fa fa-eye " aria-hidden="true"></i></a></div>
          </div>
        </div>
        <div class="saved-settings">
          <div class="profile-actions">
            <div class="profile-action-title">Comenzile mele</div>
            <div class="saved-view"><a href="<?= Url::toRoute(['/user/profile/orders']);?>"><i class="fa fa-eye" aria-hidden="true"></i></a></div>
          </div>
        </div>
       </div>
      </div>
    </div>
  </div>
</div>
