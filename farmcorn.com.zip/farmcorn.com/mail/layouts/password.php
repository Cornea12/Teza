<?php
use yii\helpers\Url;
use yii\web\UrlManager;
use yii\helpers\Html;


/* @var $this \yii\web\View view component instance */
/* @var $message \yii\mail\MessageInterface the message being composed */
/* @var $content string main view render result */
?>
<?php $this->beginPage() ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=<?= Yii::$app->charset ?>" />
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style type="text/css">
    *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    }

    body {
      margin: 0;
      background: white;
      font-weight: 300;
      width: 100%;
    }

    .container {
      width: 100%;
      max-width: 800px;
      margin: 0 auto;
      position: relative;


    }

    .header {
      width: 100%;
      z-index: 1000;
      height: 50px;
    }

    .header .logo {
      font-size: 30px;
      letter-spacing: 1px;
      padding: 15px;
      color: black;
    }


    .content{
      margin-top: 20px;
    }

    .content h1{
      color: black;
    }

    .content .content-title{
      text-align: center;
    }

    .content  a{
      text-decoration: none;
      color: blue;
      font-size: 22px;
    }


    .content p{
      padding: 20px;
      font-size: 20px;
      line-height: 30px;
      letter-spacing: 1px;
      color: black;
    }

    .welcome {
      max-width: 100%;
      object-fit: cover;
    }
    .test {
      max-width: 400px;
      height: 400px;
    }
    </style>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body>
    <?php $this->beginBody() ?>
    <div class="container">
      <header class="header">
        <div class="logo">Pharmion.com</div>
      </header>
      <div class="content">
        <h1 class="content-title">Confirmare adresa de email</h1>
        <div class="content-text">
          <p>Pentru a confirma adresa de email faceti click aici <?= $confirmationLink ?></p>
        </div>
      </div>
</div>
    <?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
