<?php

namespace app\helpers;

use Yii;
use yii\helpers\Url;



/**
 *
 */
class Helper
{

  //ia data si ora in format UNIX si le converteste in format ex. 24 Mar 2022 14:05:60
  public static function getDate($dateTime)
  {
     if (isset($dateTime) AND $dateTime != null) {
       return date('d M y H:i:s', $dateTime);
     }else {
       return 'Indisponibil';
     }
  }

  public static function date($dateTime)
  {
     if (isset($dateTime) AND $dateTime != null) {
       return date('d M Y', $dateTime);
     }else {
       return 'Indisponibil';
     }
  }

  public static function getYear($year)
  {
    if (isset($year) AND $year != null) {
      return date('Y', $year);
    }else {
      return date('Y');
    }
  }

 // Sterge imaginea daca aceasta exista inainte de actualizare
  public static function deleteImage($path, $image)
  {
    if (file_exists($path) AND $image != null AND !empty($image)) {
        unlink($path.$image);
    }
  }

  //schimba denumirea imaginii pentru a fi una unicala si o salveaza in pathul dorit, si ne intoarce denumirea imaginii
  public static function saveImageAs($uploadedImage, $path)
  {
    $imageName =  strtolower(md5(uniqid($uploadedImage)) . '.' . $uploadedImage->getExtension());
    $uploadedImage->saveAs($path . $imageName);
    return $imageName;
  }

//ne returneaza imaginea
  public static function getImage($path, $image)
  {
    if (!$image OR $image === null) {
      return Url::base('http').'/images/noimage.png';
    }
    else {
      return Url::base('http').'/'. $path. $image;
    }
  }

  //ne returneaza datele despre autor
  public static function getValue($value)
  {
    if (isset($value) AND $value != null)
    {
      return $value;
    }
    else
    {
      return 'Item inexistent sau șters';
    }
  }

  public static function createUrl($title, $link)
  {
    $url = $title;

    $url = str_replace(' ', '-', $url);

    $url = preg_replace('/[^A-Za-z0-9\-]/', '', $url);

    $link = strtolower($url);

    return $link;

  }

  public static function createTitle($title)
  {
    return $title;
  }

  public static function getYearsList($year) {
    $currentYear = date('Y');
    $yearFrom = $year;
    $yearsRange = range($yearFrom, $currentYear);
    return array_combine($yearsRange, $yearsRange);
  }

  public static function generateNrRange($from, $to)
  {
    $range = range($from, $to);
    return array_combine($range, $range);
  }

  public static function getStatus($status)
  {
    if ($status === 0) {
      return 'INACTIV';
    }
    elseif($status === 1)
    {
      return 'ACTIV';
    }
    else {
      return 'PENDING';
    }
  }

  public static function getDiscount($price, $discount)
  {
    return $price - ($price * $discount)/100;
  }

  public static function debug($item)
  {
    echo "<pre>";
    var_dump($item);
    echo "</pre>";die;
  }



}
