<?php
namespace app\components;
use Yii;


use yii\base\Widget;
use app\models\Helpers;

class FindWidget extends Widget
{

  public function run()
  {
    $helpers = Helpers::getHelpers();
    return $this->render('adminnav',[
      'helpers' => $helpers,
    ]);
  }

}
