<?php

use yii\widgets\ActiveForm;
use yii\helpers\Html;
use yii\helpers\Url;


$this->title = 'Înregistrare';
?>
<<div class="auth-bg">
  <div class="container">
    <div class="site-auth">
    <?php $form = ActiveForm::begin([
        'id' => 'login-form',
        'action' => ['/auth/registration'],
        // 'layout' => 'horizontal',
        'fieldConfig' => [
            // 'template' => "{label}\n{input}\n{error}",
            // 'labelOptions' => ['class' => 'col-lg-1 col-form-label mr-lg-3'],
            // 'inputOptions' => ['class' => 'col-lg-3 form-control'],
            'errorOptions' => ['class' => 'error'],
        ],
    ]); ?>

     <h1><?= Html::encode($this->title) ?></h1>

      <?= $form->field($model, 'firstname')->textInput(['placeholder' => 'Prenume'])->label(false); ?>

      <?= $form->field($model, 'lastname')->textInput(['placeholder' => 'Nume'])->label(false); ?>

      <?= $form->field($model, 'email')->input('email', ['placeholder' => 'Email'])->label(false); ?>

      <?= $form->field($model, 'password')->passwordInput(['placeholder' => 'Parola'])->label(false); ?>

      <?= $form->field($model, 'password_repeat')->passwordInput(['placeholder' => 'Repetă parola'])->label(false); ?>

      <input class="action" type="submit" value="Înregistrare">

      <div class="opt">
        <a href="<?= Url::toRoute(['auth/login']);?>">Ai deja un profil?</a></p>
      </div>

      <?php ActiveForm::end(); ?>

   </div>
  </div>
 </div>
