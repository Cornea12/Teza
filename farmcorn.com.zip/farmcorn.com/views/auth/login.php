<?php

/** @var yii\web\View $this */
/** @var yii\bootstrap4\ActiveForm $form */
/** @var app\models\LoginForm $model */

use yii\widgets\ActiveForm;
use yii\helpers\Html;
use yii\helpers\Url;


$this->title = 'Logare';
?>


<div class="auth-bg">
  <div class="container">
    <div class="site-auth">
    <?php $form = ActiveForm::begin([
        'class' => 'login-form',
        'fieldConfig' => [
            'errorOptions' => ['class' => 'error'],
        ],
    ]); ?>

        <h1><?= Html::encode($this->title) ?></h1>
        <label for="">Email</label>
        <?= $form->field($model, 'email')->textInput(['placeholder' => 'Emailul tau'])->label(false); ?>

         <label for="">Parola</label>
        <?= $form->field($model, 'password')->passwordInput(['placeholder' => 'Parola ta'])->label(false) ?>

        <div class="remember">
          <?= $form->field($model, 'rememberMe')->checkbox()->label(false) ?>
        </div>

          <input class="action" type="submit" value="Logare">

          <div class="opt">
            <a href="<?= Url::toRoute(['/auth/registration']);?>">Nu ești înregistrat?</a></p>
            <a href="<?= Url::toRoute(['/auth/request-password-reset']);?>">Parola uitată?</a></p>
          </div>

    <?php ActiveForm::end(); ?>
  </div>
  </div>
</div>
