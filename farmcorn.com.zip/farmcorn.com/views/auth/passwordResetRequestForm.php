<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Resetarea Parolei';
?>

<div class="auth-bg">
  <div class="container">
    <div class="site-auth">
      <?php $form = ActiveForm::begin([
          'class' => 'login-form',
          'fieldConfig' => [
              'errorOptions' => ['class' => 'error'],
          ],
      ]); ?>
        <h1><?= Html::encode($this->title) ?></h1>
        <label for="">Email</label>
        <?= $form->field($model, 'email')->textInput(['placeholder' => 'Emailul tău'])->label(false) ?>
        <input class="action" type="submit" value="Resetarea parolei">
            <?php ActiveForm::end(); ?>
          </div>
          </div>
        </div>
