<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Resetarea Parolei';
?>

<div class="auth-bg">
  <div class="container">
    <div class="site-auth">
      <?php $form = ActiveForm::begin([
          'class' => 'login-form',
          'fieldConfig' => [
              'errorOptions' => ['class' => 'error'],
          ],
      ]); ?>
        <h1><?= Html::encode($this->title) ?></h1>
        <label for="">Parola nouă</label>
                <?= $form->field($model, 'password')->passwordInput(['placeholder' => 'Parola Nouă'])->label(false) ?>
                <label for="">Repetă parola</label>
                <?= $form->field($model, 'confirm_password')->passwordInput(['placeholder' => 'Repetă parola'])->label(false) ?>
                    <input class="action" type="submit" value="Resetarea parolei">
            <?php ActiveForm::end(); ?>
          </div>
          </div>
        </div>
