<?php

/** @var yii\web\View $this */
/** @var string $content */

use app\assets\AppAsset;
use yii\helpers\Html;
use yii\helpers\Url;
use app\widgets\Alert;
AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>" class="h-100">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php $this->registerCsrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body>
<?php $this->beginBody() ?>
<div class="overlay hide">
  <img class="ajax-loader" src="..\images\ajax-loader.gif" alt="">
</div>
<div class="wrapper">
  <!-- HEADER STAR -->
<header class="header">
  <div class="container">
    <nav class="nav">
       <a href="<?=Url::toRoute(['/']);?>" class="logo"><span>Pharmion</span></a>
       <ul class="nav-links">
         <?php if (!Yii::$app->user->isGuest): ?>
               <li><a href="<?=Url::toRoute(['/user/profile']);?>">Profilul meu</a></li>
               <?php else: ?>
                 <li><a href="<?=Url::toRoute(['/auth/login']);?>">Logare/Înregistrare</a></li>
         <?php endif; ?>
         <li><a href="<?=Url::toRoute(['/product/filter'])?>">Produse</a></li>
         <li>
           <a href="<?=Url::toRoute(['/cart'])?>">
           <i class="fas fa-shopping-cart"></i>
             Coș</a>
         </li>
         <?php if (!Yii::$app->user->isGuest): ?>
               <li><a href="<?=Url::toRoute(['/auth/logout']);?>">Ieșire</a></li>
         <?php endif; ?>
         <?php if (Yii::$app->user->can('admin') OR Yii::$app->user->can('moderator') ): ?>
          <li><a href="<?=Url::toRoute(['/admin']);?>">Admin Panel</a></li>
        <?php endif; ?>
       </ul>
    </nav>
  </div>
</header>
<!-- HEADER END -->
<!-- MAIN START -->
<div class="main">
  <div class="flash-row">
    <?php if (Yii::$app->session->hasFlash('success')): ?>
    <div class="email-flash"><?= Yii::$app->session->getFlash('success') ?></div>
    <?php endif; ?>
  </div>
<?= $content ?>
</div>



<!-- MAIN END -->
<!-- FOOTER START -->
<footer class="footer">
<ul>
  <li><a href="/about-us">Despre noi & Contacte </a></li>
  <li><a href="/terms">Termeni si Conditii</a></li>
</ul>
<div class="brand">Pharmion.com 2022</div>
</footer>
<div class="modal-window-cart hide">

</div>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
