<?php
/** @var yii\web\View $this */
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use yii\helpers\Url;
use app\helpers\Helper;
use yii\helpers\ArrayHelper;
use app\models\Cart\Cart;

$this->title = 'Plasare comanda';
?>

<div class="container">
  <?php $form = ActiveForm::begin([
      'options' => ['class' => 'order-form'],
      'action' => '/order/checkout-delivery',
      'method' => 'post',
      'fieldConfig' => [
          'template' => "{input}{error}",
          'errorOptions' => ['class' => 'error'],
          'options' => [
          // 'tag' => false, // Don't wrap with "form-group" div
  ],
      ]
  ]); ?>

  <div class="bill">
    <div class="title">Detalii comandă</div>
    <div class="bill-it">Total spre plată: <?=$totalSum?> MLD</div>
    <div class="bill-it">Unități: <?=$totalQty?> </div>
    <div class="bill-it">Termen Livrare: 1 zi lucrătoare </div>
    <a href="/cart/index">Modifică</a>
  </div>

      <div class="order-info">
        <div class="title">Detalii Livrare</div>
        <label>Nume</label>
       <?= $form->field($order, 'lastname')->textInput(['autofocus' => true]) ?>

        <label>Prenume</label>
        <?= $form->field($order, 'firstname')->textInput(['autofocus' => true]) ?>


         <label>Email</label>
        <?= $form->field($order, 'email')->textInput(['autofocus' => true]) ?>

        <label>Telefon</label>
        <?= $form->field($order, 'phone')->textInput(['autofocus' => true]) ?>

        <label>Adresa de domiciliu</label>
        <?= $form->field($order, 'address')->textInput(['autofocus' => true]) ?>

         <label>Cod poștal</label>
        <?= $form->field($order, 'zip_code')->textInput(['autofocus' => true]) ?>

        <input class="sbm-order" type="submit" name="" value="Plasează comanda">
      </div>




  <?php ActiveForm::end(); ?>
</div>
