<?php
/** @var yii\web\View $this */
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use yii\helpers\Url;
use app\helpers\Helper;
use yii\helpers\ArrayHelper;
use app\models\Cart\Cart;

$this->title = 'Plasare comanda';
?>

<div class="container">
  <?php $form = ActiveForm::begin([
      'options' => ['class' => 'order-form'],
      'action' => '/order/checkout-online',
      'method' => 'post',
      'fieldConfig' => [
          'template' => "{input}{error}",
          'errorOptions' => ['class' => 'error'],
          'options' => [
          // 'tag' => false, // Don't wrap with "form-group" div
  ],
      ]
  ]); ?>

  <div class="bill">
    <div class="title">Detalii comandă</div>
    <div class="bill-it">Total spre plată: <?=$totalSum?> MLD</div>
    <div class="bill-it">Unități: <?=$totalQty?> </div>
    <div class="bill-it">Termen Livrare: 1 zi lucrătoare </div>
    <a href="/cart/index">Modifică</a>
  </div>

      <div class="order-info">
        <div class="title">Detalii Livrare</div>
        <label>Nume</label>
       <?= $form->field($order, 'lastname')->textInput(['autofocus' => true]) ?>

        <label>Prenume</label>
        <?= $form->field($order, 'firstname')->textInput(['autofocus' => true]) ?>


         <label>Email</label>
        <?= $form->field($order, 'email')->textInput(['autofocus' => true]) ?>

        <label>Telefon</label>
        <?= $form->field($order, 'phone')->textInput(['autofocus' => true]) ?>

        <label>Adresa de domiciliu</label>
        <?= $form->field($order, 'address')->textInput(['autofocus' => true]) ?>

         <label>Cod poștal</label>
        <?= $form->field($order, 'zip_code')->textInput(['autofocus' => true]) ?>
      </div>

      <div class="payment-info">
        <div class="title">Detalii Plată</div>
        <label for="" class="label">Numărul Cardului</label>
        <?= $form->field($card, 'card_number')->input(['number'])->label(false) ?>


        <label for="" class="label">Deținătorul Cardului</label>
        <?= $form->field($card, 'owner')->textInput()->label(false) ?>



          <label for="" class="label">Data Expirării</label>
          <?= $form->field($card, 'expiration')->input('month')->label(false) ?>


          <label for="" class="label">CVV</label>
          <?= $form->field($card, 'cvv')->passwordInput()->label(false) ?>



        <input class="sbm-order" type="submit" name="" value="Plătește&Comadă">
      </div>


  <?php ActiveForm::end(); ?>
</div>
