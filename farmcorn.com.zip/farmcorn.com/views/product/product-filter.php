<?php

/** @var yii\web\View $this */
use yii\helpers\Html;
use yii\helpers\Url;
use app\helpers\Helper;
use yii\helpers\ArrayHelper;
use yii\widgets\ActiveForm;
use app\models\ProductCategory\ProductCategory;
use app\models\Producer\Producer;



$this->title = 'Farmcorn.com';
?>

<?php foreach ($products as $product): ?>
  <div class="item">
    <a href="" class="it-img">
      <img src="<?=Helper::getImage($product->path, $product->image)?>" alt="">
    </a>
    <div class="producer it-el"><?= Html::encode($product->producer->name)  ?></div>
    <a href="" class="title it-el"><?= Html::encode($product->title)  ?></a>
    <?php if ($product->discount > 0): ?>
      <div class="price discount it-el">-<?= Html::encode($product->discount)  ?>%</div>
      <div class="price old it-el"><?= Html::encode($product->price)  ?> MLD</div>
      <div class="price new it-el"><?= Helper::getDiscount(Html::encode($product->price), Html::encode($product->discount))  ?> MLD</div>
    <?php else: ?>
      <div class="price it-el"><?= Html::encode($product->price)  ?> MLD</div>
    <?php endif; ?>
    <?php if ($product->stock <= 0): ?>
      <div class="add-cart ind it-el">
        <i class="fas fa-cart-arrow-down"></i>
      </div>
      <?php else: ?>
        <div class="stock dis it-el">Disponibil</div>
        <a href="<?= Url::toRoute(['/cart/add', 'id' => Html::encode($product->id)])?>"
          class="add-cart it-el" id-data='<?=Html::encode($product->id)?>'>
          <i class="fas fa-cart-arrow-down"></i>
        </a>
        <?php endif; ?>
  </div>
<?php endforeach; ?>
