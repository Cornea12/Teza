<?php
use yii\helpers\Html;
use yii\helpers\Url;
use app\helpers\Helper;
$this->title = Html::encode($model->title);
?>


<div class="container">
  <div class="product-page" style="margin-top: 50px;">
    <div class="product">
      <img src="<?=Helper::getImage($model->path, $model->image)?>" alt="">
      <div class="cart">
        <div class="producer it-el"><?= Html::encode($model->producer->name)  ?></div>
        <a href="<?= Url::toRoute(['/product/view', 'id' => Html::encode($model->id)])?>" class="title it-el"><?= Html::encode($model->title)  ?></a>
        <?php if ($model->discount > 0): ?>
          <div class="price discount it-el">-<?= Html::encode($model->discount)  ?>%</div>
          <div class="price old it-el"><?= Html::encode($model->price)  ?> MLD</div>
          <div class="price new it-el"><?= Helper::getDiscount(Html::encode($model->price), Html::encode($model->discount))  ?> MLD</div>
        <?php else: ?>
          <div class="price it-el"><?= Html::encode($model->price)  ?> MLD</div>
        <?php endif; ?>
        <?php if (!Yii::$app->user->isGuest): ?>
          <?php if ($model->stock <= 0): ?>
            <div class="add-cart ind it-el">
              <i class="fas fa-cart-arrow-down"></i>
            </div>
            <?php else: ?>
              <div class="stock dis it-el">Disponibil</div>
              <a href="<?= Url::toRoute(['/cart/add', 'id' => Html::encode($model->id)])?>"
                class="add-cart it-el" id-data='<?=Html::encode($model->id)?>'>
                <i class="fas fa-cart-arrow-down"></i>
              </a>
              <?php endif; ?>
              <?php else: ?>
                <a href="<?= Url::toRoute(['/auth/login'])?>"
                  class="add-cart-fake it-el">
                  <i class="fas fa-cart-arrow-down"></i>
                </a>
        <?php endif; ?>
      </div>
    </div>
      <div class="description"><?=$model->description?></div>
  </div>

  <section class="site-element">
    <div class="container">
      <div class="title-row">Cele mai Recente</div>
      <div class="items-row">
        <?php foreach ($modstViewed as $product): ?>
          <div class="item">
            <a href="<?= Url::toRoute(['/product/view', 'id' => Html::encode($product->id)])?>" class="it-img">
              <img src="<?=Helper::getImage($product->path, $product->image)?>" alt="">
            </a>
            <div class="producer it-el"><?= Html::encode($product->producer->name)  ?></div>
            <a href="<?= Url::toRoute(['/product/view', 'id' => Html::encode($product->id)])?>" class="title it-el"><?= Html::encode($product->title)  ?></a>
            <?php if ($product->discount > 0): ?>
              <div class="price discount it-el">-<?= Html::encode($product->discount)  ?>%</div>
              <div class="price old it-el"><?= Html::encode($product->price)  ?> MLD</div>
              <div class="price new it-el"><?= Helper::getDiscount(Html::encode($product->price), Html::encode($product->discount))  ?> MLD</div>
            <?php else: ?>
              <div class="price it-el"><?= Html::encode($product->price)  ?> MLD</div>
            <?php endif; ?>
            <?php if (!Yii::$app->user->isGuest): ?>
              <?php if ($product->stock <= 0): ?>
                <div class="add-cart ind it-el">
                  <i class="fas fa-cart-arrow-down"></i>
                </div>
                <?php else: ?>
                  <div class="stock dis it-el">Disponibil</div>
                  <a href="<?= Url::toRoute(['/cart/add', 'id' => Html::encode($product->id)])?>"
                    class="add-cart it-el" id-data='<?=Html::encode($product->id)?>'>
                    <i class="fas fa-cart-arrow-down"></i>
                  </a>
                  <?php endif; ?>
                  <?php else: ?>
                    <a href="<?= Url::toRoute(['/auth/login'])?>"
                      class="add-cart-fake it-el">
                      <i class="fas fa-cart-arrow-down"></i>
                    </a>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
    </section>
</div>
