<?php

/** @var yii\web\View $this */
use yii\helpers\Html;
use yii\helpers\Url;
use app\helpers\Helper;
use yii\helpers\ArrayHelper;
use yii\widgets\ActiveForm;
use app\models\ProductCategory\ProductCategory;
use app\models\Producer\Producer;



$this->title = 'Produsele Farmphion';
?>

  <section class="site-element">
    <div class="container">
      <section class="car-by-opt search filter" style="margin-top: 40px;">
        <!-- <div class="title">CARS FOR RENT</div> -->
      <?php $form = ActiveForm::begin([
          'action'=>['product/index'],
          'method' => 'get',
          'options' => ['class' => 'filter-form'],
          'fieldConfig' => [
              'template' => "{input}",
              'errorOptions' => ['class' => 'error'],
              'options' => [
          'tag' => false, // Don't wrap with "form-group" div
      ],
          ],]); ?>


                  <div class="filter-item">
                    <label class="filter-name">Categorie</label>
                    <?= $form->field($filter, 'category_id')
                    ->checkboxList(ArrayHelper::map(ProductCategory::find()->all(), 'id', 'name'), ['tag' => false])
                    ->label(false) ?>
                  </div>


               <div class="filter-item">
                 <label class="filter-name">Producator</label>
                 <?= $form->field($filter, 'producer_id')
                 ->checkboxList(ArrayHelper::map(Producer::find()->all(), 'id', 'name'), ['tag' => false])
                 ->label(false) ?>
               </div>

               <div class="filter-item">
                 <label class="filter-name">Pret Maxim</label>
                 <label class="filter-name range-value">1000 MLD</label>
                 <?= $form->field($filter, 'price')
                 ->input('range', ['min' => 1, 'max' => 2000, 'class' => 'price-range'])
                 ->label(false)?>
               </div>




          <!-- <input class="search-filter" type="submit" value="Search"> -->
        <?php ActiveForm::end(); ?>
  </section>
</section>
  <section class="site-element">
    <div class="container">
      <div class="title-row">Toate Produsele</div>
      <div class="items-row">
        <?php foreach ($products as $product): ?>
          <div class="item">
            <a href="" class="it-img">
              <img src="<?=Helper::getImage($product->path, $product->image)?>" alt="">
            </a>
            <div class="producer it-el"><?= Html::encode($product->producer->name)  ?></div>
            <a href="" class="title it-el"><?= Html::encode($product->title)  ?></a>
            <?php if ($product->discount > 0): ?>
              <div class="price discount it-el">-<?= Html::encode($product->discount)  ?>%</div>
              <div class="price old it-el"><?= Html::encode($product->price)  ?> MLD</div>
              <div class="price new it-el"><?= Helper::getDiscount(Html::encode($product->price), Html::encode($product->discount))  ?> MLD</div>
            <?php else: ?>
              <div class="price it-el"><?= Html::encode($product->price)  ?> MLD</div>
            <?php endif; ?>
            <?php if ($product->stock <= 0): ?>
              <div class="add-cart ind it-el">
                <i class="fas fa-cart-arrow-down"></i>
              </div>
              <?php else: ?>
                <div class="stock dis it-el">Disponibil</div>
                <a href="<?= Url::toRoute(['/cart/add', 'id' => Html::encode($product->id)])?>"
                  class="add-cart it-el" id-data='<?=Html::encode($product->id)?>'>
                  <i class="fas fa-cart-arrow-down"></i>
                </a>
                <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
    <a class="load-more-filter" href="#">Mai Mult</a>
    </section>
