<?php
/** @var yii\web\View $this */
use yii\helpers\Html;
use yii\helpers\Url;
use app\helpers\Helper;
use yii\helpers\ArrayHelper;
use app\models\Cart\Cart;

$this->title = 'Coșul meu';
?>



  <div class="container">
    <div class="page-cart">
      <?= $this->render('cart-table',[
        'userCart' => $userCart,
        'totalQty' => $totalQty,
        'totalSum' => $totalSum,
        'order' => $order,
        ]) ?>
    </div>
  </div>
