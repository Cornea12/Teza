<?php
/** @var yii\web\View $this */
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use yii\helpers\Url;
use app\helpers\Helper;
use yii\helpers\ArrayHelper;
use app\models\Cart\Cart;
?>


<?php if ($userCart): ?>
  <a class="checkout" href="/order/checkout-delivery">Achită la livrare</a>
  <a class="checkout" href="/order/checkout-online">Achită Online</a>
  <div class="cart-user">
    <table class="cart-page-table">
      <thead>
        <tr>
          <th>Imagine</th>
          <th>Denumire</th>
          <th>Preț</th>
          <th>Unitați</th>
          <th>Preț total</th>
          <th><i class="fas fa-trash-alt"></i></th>
        </tr>
      </thead>
      <?php foreach ($userCart as $cart): ?>
      <tr>
          <td> <img class="it-img" src="<?=Helper::getImage($cart->product->path, $cart->product->image)?>" alt=""> </td>
          <td><?= Html::encode($cart->product->title)?></td>
          <td><?= Helper::getDiscount(Html::encode($cart->product->price), Html::encode($cart->product->discount))?> MLD</td>
          <td><?= Html::dropDownList('quantity', $cart->quantity, Helper::generateNrRange(1, 36), ['class' => 'change-qty', 'id-data' => $cart->product_id])?></td>
          <td><?= Helper::getDiscount(Html::encode($cart->product->price), Html::encode($cart->product->discount)) * Html::encode($cart->quantity)?> MLD</td>
          <td><i id-data=<?=$cart->product_id?> class="fas fa-trash-alt del-cart-it"></i></td>
      </tr>
      <?php endforeach; ?>
      <tr>
        <th></th>
        <th></th>
        <th></th>
        <th>Unitați total</th>
        <th>Preț total</th>
        <th></th>
      </tr>
      <tr class="tb-totals">
          <td></td>
          <td></td>
          <td></td>
          <td><?= Html::encode($totalQty)?></td>
          <td><?= Html::encode(round($totalSum,2))?> MLD</td>
          <td></td>
      </tr>
    </table>
  </div>
  <a class="checkout" href="/order/checkout-delivery">Achită la livrare</a>
  <a class="checkout" href="/order/checkout-online">Achită Online</a>
  <?php else: ?>
  <div class="no-it-cart">
    <h1>Coșul este gol</h1>
    <img src="<?=Helper::getImage('images/','cart-svgrepo-com.svg')?>" alt="">
    <a href="/">Pagina Principală</a>
  </div>
<?php endif; ?>
