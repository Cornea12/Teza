<?php
/** @var yii\web\View $this */
use yii\helpers\Html;
use yii\helpers\Url;
use app\helpers\Helper;
?>


            <div class="cart-modal">
              <div class="cart-txt">Produs adăugat în coș<i class="fas fa-check-circle"></i></div>
              <div class="item cart-md">
                <a href="" class="it-img">
                  <img src="<?=Helper::getImage($userCart->product->path, $userCart->product->image)?>" alt="">
                </a>
                <div class="producer it-el"><?= Html::encode($userCart->product->producer->name)  ?></div>
                <a href="" class="title it-el"><?= Html::encode($userCart->product->title)  ?></a>
                <div class="price it-el"><?= Html::encode($userCart->product->price)  ?> MLD</div>
                <div class="qty it-el">Cantitate: <?= Html::encode($userCart->quantity)  ?> </div>
                <a href="<?= Url::toRoute(['/cart/add', 'id' => Html::encode($userCart->product->id)])?>"
                  class="add-cart it-el" id-data='<?=Html::encode($userCart->product->id)?>'>
                  <i class="fas fa-cart-arrow-down"></i><span>+1</span>
                </a>
              </div>
              <a class="cart-txt checkout"href="<?= Url::toRoute(['/cart/index'])?>">Plasează comanda <span><?=round($totalSum,2)?> MLD</span> </a>
            </div>
