<?php



use yii\helpers\Html;



$this->title = '404 - Pagina nu a fost găsită!';
?>
<div class="site-error">

  <div id="notfound">
    <div class="notfound">
      <div class="notfound-404">
        <h1>Oops!</h1>
      </div>
      <h2>404 - Pagina nu a fost găsită!</h2>
      <p>Pagina pe care o căutați ar fi putut fi eliminată dacă numele i s-a schimbat sau este temporar indisponibilă.</p>
      <a href="/">Mergi la pagina principală</a>
    </div>
  </div>

</div>
