<?php

/** @var yii\web\View $this */
use yii\helpers\Html;
use yii\helpers\Url;
use app\helpers\Helper;


$this->title = 'Farmcorn.com';
?>
  <section class="slider-container">
    <div class="mySlides fade">
     <img src="..\images\slider\1.webp">
     <div class="text"></div>
   </div>

   <div class="mySlides fade">
     <img src="..\images\slider\2.jpg">
     <div class="text"></div>
   </div>

   <div class="mySlides fade">
     <img src="..\images\slider\3.webp">
     <div class="text"></div>
   </div>

   <div class="mySlides fade">
     <img src="..\images\slider\4.webp">
     <div class="text"></div>
   </div>

   <a class="prev">&#10094;</a>
   <a class="next">&#10095;</a>

  <!-- The dots/circles -->
  <div class="dot-container">
   <span class="dot" ></span>
   <span class="dot" ></span>
   <span class="dot" ></span>
   <span class="dot" ></span>
  </div>
  </section>
</div>

<section class="site-element">
  <div class="container">
    <div class="title-row">Reducerile noastre</div>
    <div class="items-row">
      <?php foreach ($getDiscount as $product): ?>
        <div class="item">
          <a href="<?= Url::toRoute(['/product/view', 'id' => Html::encode($product->id)])?>" class="it-img">
            <img src="<?=Helper::getImage($product->path, $product->image)?>" alt="">
          </a>
          <div class="producer it-el"><?= Html::encode($product->producer->name)  ?></div>
          <a href="<?= Url::toRoute(['/product/view', 'id' => Html::encode($product->id)])?>" class="title it-el"><?= Html::encode($product->title)  ?></a>
          <?php if ($product->discount > 0): ?>
            <div class="price discount it-el">-<?= Html::encode($product->discount)  ?>%</div>
            <div class="price old it-el"><?= Html::encode($product->price)  ?> MLD</div>
            <div class="price new it-el"><?= Helper::getDiscount(Html::encode($product->price), Html::encode($product->discount))  ?> MLD</div>
          <?php else: ?>
            <div class="price it-el"><?= Html::encode($product->price)  ?> MLD</div>
          <?php endif; ?>
          <?php if (!Yii::$app->user->isGuest): ?>
            <?php if ($product->stock <= 0): ?>
              <div class="add-cart ind it-el">
                <i class="fas fa-cart-arrow-down"></i>
              </div>
              <?php else: ?>
                <div class="stock dis it-el">Disponibil</div>
                <a href="<?= Url::toRoute(['/cart/add', 'id' => Html::encode($product->id)])?>"
                  class="add-cart it-el" id-data='<?=Html::encode($product->id)?>'>
                  <i class="fas fa-cart-arrow-down"></i>
                </a>
                <?php endif; ?>
                <?php else: ?>
                  <a href="<?= Url::toRoute(['/auth/login'])?>"
                    class="add-cart-fake it-el">
                    <i class="fas fa-cart-arrow-down"></i>
                  </a>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
  </section>
<div class="container">
  <section class="producers">
    <div class="title">Producătorii noștri</div>
    <div class="opt-row">
      <?php foreach ($producers as $producer): ?>
        <a class="it">
          <div class="opt-img">
            <img src="<?=Helper::getImage($producer->path, $producer->image)?>" alt="">
          </div>
          <div class="opt-name"><?=Html::encode($producer->name)?></div>
        </a>
      <?php endforeach; ?>
    </div>
  </section>
</div>

<section class="site-element">
  <div class="container">
    <div class="title-row">Cele mai recente</div>
    <div class="items-row">
      <?php foreach ($modstViewed as $product): ?>
        <div class="item">
          <a href="<?= Url::toRoute(['/product/view', 'id' => Html::encode($product->id)])?>" class="it-img">
            <img src="<?=Helper::getImage($product->path, $product->image)?>" alt="">
          </a>
          <div class="producer it-el"><?= Html::encode($product->producer->name)  ?></div>
          <a href="<?= Url::toRoute(['/product/view', 'id' => Html::encode($product->id)])?>" class="title it-el"><?= Html::encode($product->title)  ?></a>
          <?php if ($product->discount > 0): ?>
            <div class="price discount it-el">-<?= Html::encode($product->discount)  ?>%</div>
            <div class="price old it-el"><?= Html::encode($product->price)  ?> MLD</div>
            <div class="price new it-el"><?= Helper::getDiscount(Html::encode($product->price), Html::encode($product->discount))  ?> MLD</div>
          <?php else: ?>
            <div class="price it-el"><?= Html::encode($product->price)  ?> MLD</div>
          <?php endif; ?>
          <?php if (!Yii::$app->user->isGuest): ?>
            <?php if ($product->stock <= 0): ?>
              <div class="add-cart ind it-el">
                <i class="fas fa-cart-arrow-down"></i>
              </div>
              <?php else: ?>
                <div class="stock dis it-el">Disponibil</div>
                <a href="<?= Url::toRoute(['/cart/add', 'id' => Html::encode($product->id)])?>"
                  class="add-cart it-el" id-data='<?=Html::encode($product->id)?>'>
                  <i class="fas fa-cart-arrow-down"></i>
                </a>
                <?php endif; ?>
                <?php else: ?>
                  <a href="<?= Url::toRoute(['/auth/login'])?>"
                    class="add-cart-fake it-el">
                    <i class="fas fa-cart-arrow-down"></i>
                  </a>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
  </section>

 <?php foreach ($getCategories as $category): ?>
   <section class="site-element">
     <div class="container">
       <div class="title-row"><?= Html::encode($category->name) ?></div>
       <div class="items-row">
         <?php $productByCategory = $category->ProductsByCategory; ?>
         <?php foreach ($productByCategory as $product): ?>
           <div class="item">
             <a href="<?= Url::toRoute(['/product/view', 'id' => Html::encode($product->id)])?>" class="it-img">
               <img src="<?=Helper::getImage($product->path, $product->image)?>" alt="">
             </a>
             <div class="producer it-el"><?= Html::encode($product->producer->name)  ?></div>
             <a href="<?= Url::toRoute(['/product/view', 'id' => Html::encode($product->id)])?>" class="title it-el"><?= Html::encode($product->title)  ?></a>
             <?php if ($product->discount > 0): ?>
               <div class="price discount it-el">-<?= Html::encode($product->discount)  ?>%</div>
               <div class="price old it-el"><?= Html::encode($product->price)  ?> MLD</div>
               <div class="price new it-el"><?= Helper::getDiscount(Html::encode($product->price), Html::encode($product->discount))  ?> MLD</div>
             <?php else: ?>
               <div class="price it-el"><?= Html::encode($product->price)  ?> MLD</div>
             <?php endif; ?>
             <?php if (!Yii::$app->user->isGuest): ?>
               <?php if ($product->stock <= 0): ?>
                 <div class="add-cart ind it-el">
                   <i class="fas fa-cart-arrow-down"></i>
                 </div>
                 <?php else: ?>
                   <div class="stock dis it-el">Disponibil</div>
                   <a href="<?= Url::toRoute(['/cart/add', 'id' => Html::encode($product->id)])?>"
                     class="add-cart it-el" id-data='<?=Html::encode($product->id)?>'>
                     <i class="fas fa-cart-arrow-down"></i>
                   </a>
                   <?php endif; ?>
                   <?php else: ?>
                     <a href="<?= Url::toRoute(['/auth/login'])?>"
                       class="add-cart-fake it-el">
                       <i class="fas fa-cart-arrow-down"></i>
                     </a>
             <?php endif; ?>
           </div>
         <?php endforeach; ?>
       </div>
     </div>
     </section>
 <?php endforeach; ?>
