<?php

$this->title = 'Termeni si conditii'
?>



<?php if ($model): ?>

    <div class="site-container">
      <div class="info-pages">
        <div class="info-column">
          <div class="page-start">
            <h1 class="page-title"><?= $model->title ?></h1>
            <div class="page-update">Ultima Modificare: <?= $model->getDateUpdate() ?></div>
          </div>
          <div class="page-body"><?= $model->content ?></div>
        </div>
      </div>
    </div>


<?php endif; ?>
