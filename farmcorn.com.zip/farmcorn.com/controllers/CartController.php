<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\Product\Product;
use app\models\Cart\Cart;
use app\models\Order\Order;
use yii\web\NotFoundHttpException;
use app\helpers\Helper;




/**
 *
 */
class CartController extends Controller
{
  public function behaviors(){
  return [
      'access' => [
          'class' => \yii\filters\AccessControl::className(),
          'rules' => [
              [
                  'allow' => true,
                  'roles' => ['@'],
              ],
          ],
      ],
  ];
}


public function actionIndex()
{
  if (!Yii::$app->user->isGuest) {
    $order = new Order;
    $userCart = Cart::showCart();
    $totalQty = Cart::cartQtySum();
    $totalSum = 0;
    foreach ($userCart as $sum) {
      $totalSum += Helper::getDiscount($sum->product->price, $sum->product->discount) * $sum->quantity;
    }
    // Helper::debug($totalSum);
  }
  else {
  return $this->redirect('/auth/login');
  }
  return $this->render('index',[
    'userCart' => $userCart,
    'totalQty' => $totalQty,
    'totalSum' => $totalSum,
    'order' => $order,
  ]);
}

public function actionAdd()
{

  $id = $_GET['id'];
  $product = Product::findCart($id);
  $cart = new Cart();
  $this->layout = false;
  if (Yii::$app->request->isAjax) {
    if (!$product)  throw new \yii\web\HttpException(404,'Out of stock');

    if (!Yii::$app->user->isGuest) {
      $cart->addCartUser($product, $id);
      $userCart = Cart::findCartOne($id);
      $totalQty = Cart::cartQtySum();
      $totalCart = Cart::showCart();
      $totalSum = 0;
      foreach ($totalCart as $sum) {
        $totalSum += Helper::getDiscount($sum->product->price, $sum->product->discount) * $sum->quantity;
      }
      // Helper::debug($totalSum);
    }
    else {
      return $this->redirect('/auth/login');
    }
  }
  else {
   throw new NotFoundHttpException('The requested page does not exist.');
  }

  return $this->render('cart-modal',[
    'userCart' => $userCart,
    'totalQty' => $totalQty,
    'totalSum' => $totalSum,
  ]);

}

public function actionModify()
{
  $id = $_GET['id'];
  $quantity = $_GET['qty'];
  $cart = new Cart();
  $product = Cart::findCartOne($id);
  $this->layout = false;
  if (Yii::$app->request->isAjax) {
    if (!$product)  throw new \yii\web\HttpException(404,'Out of stock');
    $product->updateQty($id, $quantity);
    $userCart = Cart::showCart();
    $totalQty = Cart::cartQtySum();
    $totalSum = 0;
    foreach ($userCart as $sum) {
      $totalSum += Helper::getDiscount($sum->product->price, $sum->product->discount) * $sum->quantity;
    }
  }
  else {
    throw new NotFoundHttpException('The requested page does not exist.');
  }

  return $this->render('cart-table',[
    'userCart' => $userCart,
    'totalQty' => $totalQty,
    'totalSum' => $totalSum,
  ]);
}

public function actionDelete()
{
  $id = $_GET['id'];
  $product = Cart::findCartOne($id);
  $this->layout = false;
  if (Yii::$app->request->isAjax) {
    if (!$product)  throw new \yii\web\HttpException(404,'Out of stock');
    $product->delete();
    $userCart = Cart::showCart();
    $totalQty = Cart::cartQtySum();
    $totalSum = 0;
    foreach ($userCart as $sum) {
      $totalSum += Helper::getDiscount($sum->product->price, $sum->product->discount) * $sum->quantity;
    }
  }
  else {
    throw new NotFoundHttpException('The requested page does not exist.');
  }

  return $this->render('cart-table',[
    'userCart' => $userCart,
    'totalQty' => $totalQty,
    'totalSum' => $totalSum,
  ]);
}
public function findItem($product, $user)
{
  if (($model = Cart::findOne(['product_id' => $product, 'user_id' => $user])) !== null) {
      return $model;
  }

  throw new NotFoundHttpException('The requested page does not exist.');
}

}
