<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\Product\Product;
use app\models\Product\ProductFilter;
use app\helpers\Helper;
use app\models\ProductCategory\ProductCategory;
use app\models\LoginForm;
use app\models\ContactForm;
use app\models\Cart\Cart;

class ProductController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
     public function actionView($id)
     {
       $modstViewed = Product::getMostViewed();
           return $this->render('view', [
               'model' => $this->findModel($id),
               'modstViewed' => $modstViewed,
           ]);
     }
    public function actionFilter()
    {

       $filter = new ProductFilter;
       $products = $filter->getProductFilter($_GET);
        return $this->render('filter',
      [
        'products' => $products,
        'filter' => $filter,
      ]);
    }


    public function actionLoad()
    {

      $limit = $_GET['limit'];
      $filter = new ProductFilter;
      $products = $filter->getProductFilter($_GET, $limit);
      $this->layout = false;

      return $this->render('product-filter',
    [
      'products' => $products,
    ]);

    }


    protected function findModel($id)
    {
        if (($model = Product::findOne(['id' => $id, 'status' => 1])) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }


}
