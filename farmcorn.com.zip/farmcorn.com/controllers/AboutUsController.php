<?php

namespace app\controllers;

use Yii;
use app\models\Info\AboutUs;
use yii\web\NotFoundHttpException;
use yii\web\Controller;



class AboutUsController extends Controller
{



    public function actionIndex()
    {

      $model = AboutUs::getAbout();

      return $this->render('index',[
        'model' => $model,
      ]);
    }



}
