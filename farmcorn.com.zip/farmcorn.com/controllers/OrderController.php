<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\Product\Product;
use app\models\Cart\Cart;
use app\models\OrderItem\OrderItem;
use app\models\Payment\forms\CardForm;
use app\models\Payment\Payment;
use app\models\Order\Order;
use yii\web\NotFoundHttpException;
use app\helpers\Helper;




/**
 *
 */
class OrderController extends Controller
{

  public function behaviors(){
  return [
      'access' => [
          'class' => \yii\filters\AccessControl::className(),
          'rules' => [
              [
                  'allow' => true,
                  'roles' => ['@'],
              ],
          ],
      ],
  ];
}


public function actionCheckoutOnline()
{
  if (!Yii::$app->user->isGuest) {
    $order = new Order;
    $card = new CardForm;
    $orderItem = new OrderItem;
    $payment = new Payment;
    $cart = new Cart;
    $userCart = Cart::showCart();
    // Helper::debug($userCart);
    if (!empty($userCart)) {
      $totalQty = Cart::cartQtySum();
      $totalSum = 0;
      foreach ($userCart as $sum) {
        $totalSum += Helper::getDiscount($sum->product->price, $sum->product->discount) * $sum->quantity;
      }
      if ($this->request->isPost && $order->load($this->request->post()) && $order->save()) {
          $order->saveOrderDetails($totalQty, $totalSum);
          $payment->payOnline($order);
          $order->addPaymentId($payment);
          $orderItem->saveItem($userCart, $order->id);
          $order->sendConfirmationOrder($userCart);
          $cart->deleteItems($userCart);
        Yii::$app->session->setFlash('success', 'Comanda a fost plasată cu success, verificați poșta');
          return $this->redirect(['/user/profile/orders']);
      }
    }
    else {
      return $this->redirect(['/cart/index']);
    }
  }

  return $this->render('checkout-online',[
    'order' => $order,
    'card' => $card,
    'totalSum' => $totalSum,
    'totalQty' => $totalQty,
  ]);
}

public function actionCheckoutDelivery()
{
  if (!Yii::$app->user->isGuest) {
    $order = new Order;
    $orderItem = new OrderItem;
    $payment = new Payment;
    $cart = new Cart;
    $userCart = Cart::showCart();
    // Helper::debug($userCart);
    if (!empty($userCart)) {
      $totalQty = Cart::cartQtySum();
      $totalSum = 0;
      foreach ($userCart as $sum) {
        $totalSum += Helper::getDiscount($sum->product->price, $sum->product->discount) * $sum->quantity;
      }
      if ($this->request->isPost && $order->load($this->request->post()) && $order->save()) {
          $order->saveOrderDetails($totalQty, $totalSum);
          $payment->payCash($order);
          $order->addPaymentId($payment);
          $orderItem->saveItem($userCart, $order->id);
          $order->sendConfirmationOrder($userCart);
          $cart->deleteItems($userCart);
          Yii::$app->session->setFlash('success', 'Comanda a fost plasată cu success, verificați poșta');
          return $this->redirect(['/user/profile/orders']);
      }
    }
    else {
      return $this->redirect(['/cart/index']);
    }
  }

  return $this->render('checkout-delivery',[
    'order' => $order,
    'totalSum' => $totalSum,
    'totalQty' => $totalQty,
  ]);
}
}
