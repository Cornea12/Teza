<?php

namespace app\controllers;

use Yii;
use app\models\Info\Terms;
use yii\web\NotFoundHttpException;
use yii\web\Controller;



class TermsController extends Controller
{



    public function actionIndex()
    {

      $model = Terms::getTerms();

      return $this->render('index',[
        'model' => $model,
      ]);

      return $this->render('index');
    }



}
