<?php

namespace app\controllers;


use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\User\forms\LoginForm;
use app\models\User\forms\RegistrationForm;
use app\models\User\forms\PasswordResetRequestForm;
use app\models\User\forms\ResetPasswordForm;


class AuthController extends Controller
{
  public function actionRegistration()
  {

    if (!Yii::$app->user->isGuest) {
        return $this->goHome();
    }
    $model = new RegistrationForm;
    if ($this->request->isPost) {
        if ($model->load($this->request->post())  AND $model->register() ) {
          Yii::$app->session->setFlash('success', 'Utilizatorul <b>'."$model->email".'</b> adăugat cu success, confirmati adresa de email');
            return $this->redirect('/');
        }
    }
    return $this->render('registration',[
      'model' => $model,
    ]);
  }

  public function actionLogin()
  {
    $model = new LoginForm;
    if (!Yii::$app->user->isGuest) {
        return $this->goHome();
    }

    if ($model->load(Yii::$app->request->post()) && $model->login()) {
        return $this->redirect('/user/profile');
    }

   return $this->render('login',[
     'model' => $model
   ]);
  }

  public function actionLogout()
  {
      Yii::$app->user->logout();

      return $this->goHome();
  }


  public function actionRequestPasswordReset()
 {
     $model = new PasswordResetRequestForm();

     if ($model->load(Yii::$app->request->post()) && $model->validate()) {
         if ($model->sendEmail()) {
             Yii::$app->session->setFlash('success', 'E-mailul de resetare a parolei a fost trimis cu succes, verificați-l pentru instrucțiuni suplimentare.');
             return $this->goHome();
         } else {
             Yii::$app->session->setFlash('error', 'Ne pare rău, nu putem reseta parola pentru e-mailul furnizat. Vă rugăm să încercați mai târziu.');
         }
     }

     return $this->render('passwordResetRequestForm', [
         'model' => $model,
     ]);
 }

 /**
  * Resets password.
  *
  * @param string $token
  * @return mixed
  * @throws BadRequestHttpException
  */
 public function actionResetPassword($token)
 {
     try {
         $model = new ResetPasswordForm($token);
     } catch (InvalidParamException $e) {
         throw new BadRequestHttpException($e->getMessage());
     }

     if ($model->load(Yii::$app->request->post()) && $model->validate() && $model->resetPassword()) {
         Yii::$app->session->setFlash('success', 'Parola nouă a fost salvată cu succes');
         return $this->goHome();
     }

     return $this->render('resetPasswordForm', [
         'model' => $model,
       ]);
   }

   public function actionConfirmEmail()
   {
     if (!Yii::$app->user->isGuest)
     {
       return $this->goHome();
     }

     //link creating email code and email user
     $email_token = Htmlspecialchars(Yii::$app->request->get('email_token'));
     $email = Htmlspecialchars(Yii::$app->request->get('email'));

     //search for user with this emai and eamial code
     $model = User::find()->where(['email' => $email,'email_token' => $email_token])->one();

     if ($model->id)
     {
       $model->email_token = null;
       $model->status = User::USER_ACTIVE;
       $model->save();
       Yii::$app->session->setFlash('success', 'Bravo, email-ul tau a fost confirmat cu succes, acum te poti autentifica!!!');
       return $this->redirect('/');
     }
     else
     {
       Yii::$app->session->setFlash('error', 'Sorry, we are unable to confirm account for email provided.Please, try it later.');
       return $this->goHome();
     }
   }
}
