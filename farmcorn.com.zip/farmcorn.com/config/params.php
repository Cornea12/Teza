<?php

return [
    'adminEmail' => 'cornea.ion@list.ru',
    'user.passwordResetTokenExpire' => 3600,
    // 'senderEmail' => 'noreply@example.com',
    // 'senderName' => 'Example.com mailer',
];
